import pandas as pd
import streamlit as st

import database as db
from utils import helpers as h

DESCRIPTIONS = """
customer.customer_id|Surrogate primary key
customer.full_name|Customer's full name
customer.email|Unique e-mail address (case-insensitive)
customer.phone|Contact phone number
customer.created_at|Registration timestamp
movie.movie_id|Surrogate primary key
movie.title|Movie title
movie.genre|Genre (Action, Sci-Fi ...)
movie.duration_minutes|Running time in minutes (> 0)
movie.language|Spoken language
movie.rating|Age rating (G, PG, PG-13, R, NC-17)
movie.release_date|Release date
movie.status|Now Showing / Coming Soon / Archived
screen.screen_id|Surrogate primary key
screen.screen_name|Unique screen name
screen.capacity|Number of seats (> 0), kept equal to seat rows
screen.screen_type|Standard / IMAX / Premium / VIP
screen.status|Active / Maintenance / Closed
seat.seat_id|Surrogate primary key
seat.screen_id|Screen the seat belongs to
seat.row_label|Row letter (A, B ...)
seat.seat_number|Seat number within the row
seat.seat_type|Standard / Premium / VIP
show.show_id|Surrogate primary key
show.movie_id|Movie being screened
show.screen_id|Screen hosting the show
show.show_date|Show date (YYYY-MM-DD)
show.start_time|Start time (HH:MM)
show.end_time|End = start + duration + cleaning buffer
show.ticket_price|Base ticket price (> 0)
show.status|Upcoming / Now Showing / Completed / Cancelled
booking.booking_id|Surrogate primary key
booking.customer_id|Customer who booked
booking.show_id|Show that was booked
booking.booking_datetime|When the booking was made
booking.booking_status|Pending / Confirmed / Cancelled
booking.total_amount|Total price of all seats (>= 0)
booking_seat.booking_seat_id|Surrogate primary key
booking_seat.booking_id|Parent booking
booking_seat.show_id|Show (part of the one-seat-per-show rule)
booking_seat.seat_id|Reserved seat
booking_seat.price|Price of this seat (base price x seat-type multiplier)
booking_seat.seat_status|Active = reserved, Released = freed by cancellation
payment.payment_id|Surrogate primary key
payment.booking_id|Booking being paid
payment.payment_method|Cash / Card / Digital Wallet
payment.amount|Amount paid (>= 0), equals booking total
payment.payment_datetime|Payment timestamp
payment.payment_status|Paid / Pending / Refunded / Failed
payment.transaction_reference|Unique transaction reference
ticket.ticket_id|Surrogate primary key
ticket.booking_id|Booking the ticket belongs to
ticket.booking_seat_id|Seat allocation the ticket represents (one ticket per seat)
ticket.ticket_code|Unique ticket code printed on the ticket
ticket.issued_at|Issue timestamp
concession_item.item_id|Surrogate primary key
concession_item.item_name|Unique item name
concession_item.category|Snacks, Beverages, Combos ...
concession_item.unit_price|Current selling price (> 0)
concession_item.stock_quantity|Units in stock (>= 0)
concession_item.status|Active / Inactive
concession_sale.concession_sale_id|Surrogate primary key
concession_sale.customer_id|Optional customer (walk-in = NULL)
concession_sale.booking_id|Optional related booking
concession_sale.sale_datetime|Sale timestamp
concession_sale.total_amount|Sale total (>= 0)
concession_sale_item.sale_item_id|Surrogate primary key
concession_sale_item.concession_sale_id|Parent sale
concession_sale_item.item_id|Item sold
concession_sale_item.quantity|Units sold (> 0)
concession_sale_item.unit_price|Price at the time of sale (historical price)
cancellation.cancellation_id|Surrogate primary key
cancellation.booking_id|Cancelled booking (one cancellation per booking)
cancellation.cancellation_datetime|When it was cancelled
cancellation.reason|Customer's reason
cancellation.refund_percentage|Policy percentage applied (0-100)
cancellation.refund_amount|Calculated refund (>= 0)
cancellation.cancellation_status|Processed / Rejected
refund.refund_id|Surrogate primary key
refund.cancellation_id|Cancellation that triggered the refund
refund.payment_id|Payment being refunded
refund.refund_amount|Refunded amount (never above payment amount)
refund.refund_datetime|Refund timestamp
refund.refund_status|Processed / Pending
"""
DESC = dict(line.split("|", 1) for line in DESCRIPTIONS.strip().splitlines())
MAIN_TABLES = ["customer", "movie", "screen", "seat", "show", "booking", "booking_seat", "payment", "ticket",
               "concession_item", "concession_sale", "concession_sale_item", "cancellation", "refund"]

FDS = [("customer_id", "full_name, email, phone"), ("movie_id", "title, genre, duration_minutes, language, rating"),
       ("screen_id", "screen_name, capacity, screen_type"), ("seat_id", "screen_id, row_label, seat_number, seat_type"),
       ("show_id", "movie_id, screen_id, show_date, start_time, end_time, ticket_price"),
       ("booking_id", "customer_id, show_id, booking_datetime, booking_status, total_amount"),
       ("payment_id", "booking_id, payment_method, amount, payment_datetime, payment_status"),
       ("item_id", "item_name, category, unit_price, stock_quantity")]


def _dictionary(table):
    cols = db.query_all(f'PRAGMA table_info("{table}")')
    fks = {r["from"] for r in db.query_all(f'PRAGMA foreign_key_list("{table}")')}
    uniques = set()
    for idx in db.query_all(f'PRAGMA index_list("{table}")'):
        if idx["unique"] and idx["origin"] in ("u", "c") and not idx["partial"]:
            for c in db.query_all(f'PRAGMA index_info("{idx["name"]}")'):
                uniques.add(c["name"])
    rows = []
    for c in cols:
        key = "PK" if c["pk"] else "FK" if c["name"] in fks else "UNIQUE" if c["name"] in uniques else ""
        rows.append({"Attribute": c["name"], "Data Type": c["type"], "Key": key,
                     "Null Allowed?": "No" if c["notnull"] or c["pk"] else "Yes",
                     "Description": DESC.get(f"{table}.{c['name']}", "")})
    return pd.DataFrame(rows)


def render():
    h.page_header("About / System Information", "Architecture, normalisation, constraints and data dictionary", "ℹ️")
    t1, t2, t3, t4 = st.tabs(["🏗️ Overview", "📐 Normalisation (3NF)", "🔒 Constraints & Rules", "📖 Data Dictionary"])

    with t1:
        st.markdown("""
**CineSphere** is a cinema management and booking prototype covering scheduling, seat reservation, payments,
concessions, cancellations/refunds and analytics.

| Layer | Technology |
|---|---|
| GUI | Streamlit (custom dark/gold CSS) |
| Database | SQLite via `sqlite3`, 14 business tables + `app_user`, 9 views, 5 triggers |
| Analytics | Pandas + Plotly |
| Security | Salted SHA-256 password hashes, parameterised SQL only |
""")
        st.markdown("**Entity relationships**")
        st.code("""CUSTOMER 1──* BOOKING *──1 SHOW *──1 MOVIE
                          |          *──1 SCREEN 1──* SEAT
                          |
BOOKING 1──* BOOKING_SEAT *──1 SEAT      BOOKING 1──* PAYMENT 1──* REFUND *──1 CANCELLATION 1──1 BOOKING
BOOKING_SEAT 1──1 TICKET                 CONCESSION_SALE 1──* CONCESSION_SALE_ITEM *──1 CONCESSION_ITEM""", language="text")

    with t2:
        c1, c2, c3 = st.columns(3)
        c1.markdown("**1NF**  \nAll attributes are atomic, every table has a primary key, no repeating groups "
                    "(seats of a booking live in `booking_seat`, not in a comma-separated column).")
        c2.markdown("**2NF**  \nNo partial dependencies: every table uses a single-column surrogate key, so each non-key "
                    "attribute depends on the whole key. Line-item tables (`booking_seat`, `concession_sale_item`) hold only facts about the line.")
        c3.markdown("**3NF**  \nNo transitive dependencies: e.g. a booking stores `customer_id`, not the customer's name/e-mail; "
                    "a show stores `movie_id`, not the title or duration; price at sale time is stored in the line item because it is historical data.")
        st.markdown("##### Functional dependencies")
        h.show_df(pd.DataFrame([{"Determinant": a, "→ Determines": b} for a, b in FDS]))
        st.markdown("##### Anomalies prevented by decomposition")
        st.markdown("""
- **Update anomaly** – changing a movie's title or a customer's phone number is done in exactly one row.
- **Insertion anomaly** – a movie, screen or customer can be stored before any show/booking exists.
- **Deletion anomaly** – cancelling the last booking of a show does not erase the movie, screen or customer information.
""")

    with t3:
        st.markdown("""
| Rule | Where it is enforced |
|---|---|
| One seat per screening | Unique index on `booking_seat(show_id, seat_id)` for **active** seats (cancelled seats are *released* and can be rebooked) |
| No overlapping shows | Python pre-check + `trg_show_no_overlap_insert / _update` triggers (`new_start < end AND new_end > start`) |
| Positive quantity / price | `CHECK (quantity > 0)`, `CHECK (ticket_price > 0)`, `CHECK (unit_price > 0)`, `CHECK (amount >= 0)` |
| Stock cannot go negative | `CHECK (stock_quantity >= 0)` + validation in `complete_concession_sale()` |
| Refund ≤ payment | `trg_refund_not_above_payment` + `min()` in the refund calculation |
| No cancellation after start | `trg_cancel_before_show_start` + eligibility check |
| Atomic booking | `create_booking()` runs booking, seats, payment and tickets in **one transaction** (ROLLBACK on any error) |
""")
        st.markdown("##### Cancellation policy")
        st.markdown("| Time before show | Refund |\n|---|---|\n| 24+ hours | 100% |\n| 6 – 24 hours | 75% |\n| 2 – 6 hours | 50% |\n| Under 2 hours | 0% |\n| After start | Cancellation prohibited |")
        st.info("Try them live in **Database Viewer → Constraint Lab**.", icon="🧪")

    with t4:
        table = st.selectbox("Table", MAIN_TABLES)
        h.show_df(_dictionary(table))
