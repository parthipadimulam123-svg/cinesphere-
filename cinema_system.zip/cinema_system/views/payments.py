import plotly.express as px
import streamlit as st

import database as db
from utils import helpers as h


def render():
    h.page_header("Payments", "Transactions, payment methods and pending settlements", "💳")
    df = db.get_payments()
    df["date"] = df["payment_datetime"].str[:10]
    c1, c2, c3 = st.columns(3)
    day = c1.selectbox("Date", ["All dates"] + sorted(df["date"].unique(), reverse=True))
    methods = c2.multiselect("Method", db.PAYMENT_METHODS)
    statuses = c3.multiselect("Status", ["Paid", "Pending", "Refunded", "Failed"])
    view = df
    if day != "All dates":
        view = view[view["date"] == day]
    if methods:
        view = view[view["payment_method"].isin(methods)]
    if statuses:
        view = view[view["payment_status"].isin(statuses)]
    h.kpi_row([("Collected", h.money(view[view["payment_status"].isin(["Paid", "Refunded"])]["amount"].sum()), "💰", "paid + refunded"),
               ("Pending", int((view["payment_status"] == "Pending").sum()), "🟡", "awaiting payment"),
               ("Refunded", int((view["payment_status"] == "Refunded").sum()), "🟣", "payments"),
               ("Failed", int((view["payment_status"] == "Failed").sum()), "🔴", "payments")])
    st.write("")
    left, right = st.columns([3, 1.4])
    with left:
        out = view.assign(payment_status=view["payment_status"].map(h.status_label)).rename(columns={
            "transaction_reference": "Transaction ID", "booking_id": "Booking ID", "customer": "Customer", "amount": "Amount ($)",
            "payment_method": "Method", "payment_datetime": "Date", "payment_status": "Status"})
        h.show_df(out[["Transaction ID", "Booking ID", "Customer", "Amount ($)", "Method", "Date", "Status"]])
    with right, st.container(border=True):
        by = view.groupby("payment_method", as_index=False)["amount"].sum()
        if not by.empty:
            st.plotly_chart(h.style_fig(px.pie(by, names="payment_method", values="amount", hole=0.55, title="By method"), 280))

    pending = df[df["payment_status"] == "Pending"]
    if not pending.empty:
        st.subheader("🟡 Pending payments")
        labels = {int(r.payment_id): f"{r.transaction_reference} · {r.customer} · {h.money(r.amount)}" for r in pending.itertuples()}
        pid = st.selectbox("Select pending payment", list(labels), format_func=labels.get)
        if st.button("Mark as paid & issue tickets", type="primary"):
            try:
                db.complete_pending_payment(pid)
                h.flash("success", "Payment completed. Booking confirmed and tickets issued.")
                st.rerun()
            except Exception as exc:
                st.error(db.friendly_error(exc), icon="❌")
