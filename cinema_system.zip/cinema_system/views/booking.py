import html
import time

import streamlit as st

import database as db
from utils import helpers as h

STEPS = ["Customer", "Movie", "Show", "Seats", "Summary", "Payment", "Confirmation"]
METHOD_ICON = {"Cash": "💵 Cash", "Card": "💳 Card", "Digital Wallet": "📱 Digital Wallet"}


def _state():
    return st.session_state.setdefault("bk", {"step": 1})


def _go(step, **kw):
    s = _state()
    s.update(kw)
    s["step"] = step


def _reset():
    st.session_state["bk"] = {"step": 1}
    for k in ("bk_seats_sel", "bk_seats_show"):
        st.session_state.pop(k, None)


def _nav(back=None, next_label=None, next_step=None, disabled=False, **kw):
    c1, c2, _ = st.columns([1, 1.4, 4])
    if back and c1.button("← Back", key=f"back_{back}"):
        _go(back)
        st.rerun()
    if next_label and c2.button(next_label, type="primary", disabled=disabled, key=f"next_{next_step}"):
        _go(next_step, **kw)
        st.rerun()


def _step_bar(step):
    chips = "".join(f'<span class="cs-step {"active" if i == step else "done" if i < step else ""}">{i}. {n}</span>'
                    for i, n in enumerate(STEPS, 1))
    st.markdown(f'<div class="cs-steps">{chips}</div>', unsafe_allow_html=True)
    st.progress(step / len(STEPS))


def render():
    h.page_header("Customer Booking", "Guided 7-step ticket booking with live seat selection", "🎟️")
    s = _state()
    _step_bar(s["step"])
    {1: step_customer, 2: step_movie, 3: step_show, 4: step_seats, 5: step_summary, 6: step_payment, 7: step_done}[s["step"]]()


def step_customer():
    s = _state()
    st.subheader("Step 1 · Select or create a customer")
    q = st.text_input("Search by name, email or phone", placeholder="e.g. priya")
    found = db.search_customers(q)
    if found.empty:
        st.warning("No customer found – create a new one below.", icon="⚠️")
    else:
        labels = {int(r.customer_id): f"{r.full_name} · {r.email} · {r.phone}" for r in found.itertuples()}
        cid = st.selectbox("Matching customers", list(labels), format_func=labels.get)
        _nav(next_label="Continue with this customer →", next_step=2, customer_id=cid)
    with st.expander("➕ New customer", expanded=found.empty):
        c1, c2, c3 = st.columns(3)
        name, email, phone = c1.text_input("Full name *"), c2.text_input("Email *"), c3.text_input("Phone *")
        if st.button("Create customer & continue", type="primary"):
            try:
                _go(2, customer_id=db.add_customer(name, email, phone))
                st.rerun()
            except Exception as exc:
                st.error(db.friendly_error(exc), icon="❌")


def step_movie():
    st.subheader("Step 2 · Choose a movie")
    movies = db.query_df("""SELECT m.movie_id, m.title, m.genre, m.duration_minutes, m.language, m.rating,
                                   COUNT(sh.show_id) AS shows
                            FROM movie m INNER JOIN show sh ON sh.movie_id = m.movie_id
                            WHERE sh.status = 'Upcoming' GROUP BY m.movie_id ORDER BY m.title""")
    if movies.empty:
        st.info("No movies with upcoming shows.")
    for i, row in enumerate(movies.itertuples()):
        if i % 3 == 0:
            cols = st.columns(3)
        with cols[i % 3], st.container(border=True):
            st.markdown(f"<div class='cs-card' style='margin:0'><h4>{html.escape(row.title)}</h4><div class='meta'>"
                        f"{row.genre} · {row.duration_minutes} min · {row.rating} · {row.language}<br>"
                        f"🎞️ {row.shows} upcoming shows</div></div>", unsafe_allow_html=True)
            if st.button("Select", key=f"mv_{row.movie_id}"):
                _go(3, movie_id=int(row.movie_id))
                st.rerun()
    _nav(back=1)


def step_show():
    s = _state()
    st.subheader("Step 3 · Choose a show")
    shows = db.get_shows(open_only=True)
    shows = shows[(shows["movie_id"] == s["movie_id"]) & (shows["status"] == "Upcoming")].head(14)
    for r in shows.itertuples():
        with st.container(border=True):
            c = st.columns([2, 1.2, 1.2, 1.4, 1])
            c[0].markdown(f"**{r.movie_title}**  \n{r.show_date} · {r.start_time}–{r.end_time}")
            c[1].markdown(f"**{r.screen_name}**  \nScreen")
            c[2].markdown(f"**{h.money(r.ticket_price)}**  \nbase price")
            c[3].markdown(f"**{r.available_seats}** seats  \n{r.occupancy_pct}% full")
            if c[4].button("Select", key=f"sh_{r.show_id}", disabled=r.available_seats == 0):
                _go(4, show_id=int(r.show_id))
                st.rerun()
    if shows.empty:
        st.info("No upcoming shows for this movie.")
    _nav(back=2)


def step_seats():
    s = _state()
    st.subheader("Step 4 · Select seats")
    with st.container(border=True):
        chosen, total = h.render_seat_map(s["show_id"], "bk_seats")
    if chosen.empty:
        st.warning("Please select at least one seat.", icon="⚠️")
    _nav(back=3, next_label="Continue to summary →", next_step=5, disabled=chosen.empty,
         seat_ids=[int(x) for x in chosen["seat_id"]])


def step_summary():
    s = _state()
    st.subheader("Step 5 · Booking summary")
    seats = db.get_seat_map(s["show_id"])
    seats = seats[seats["seat_id"].isin(s["seat_ids"])].copy()
    show = db.query_one("SELECT * FROM vw_show_occupancy WHERE show_id = ?", (s["show_id"],))
    cust = db.query_one("SELECT * FROM customer WHERE customer_id = ?", (s["customer_id"],))
    seats["Price"] = seats["seat_type"].map(lambda t: db.seat_price(show["ticket_price"], t)).astype(float)
    total = round(float(seats["Price"].sum()), 2)
    s["total"] = total
    with st.container(border=True):
        for k, val in [("Customer", cust["full_name"]), ("Movie", show["movie_title"]), ("Screen", show["screen_name"]),
                       ("Date", show["show_date"]), ("Time", f"{show['start_time']} – {show['end_time']}"),
                       ("Seats", ", ".join(seats["seat_label"])), ("Number of tickets", len(seats))]:
            st.markdown(f'<div class="cs-row"><span>{k}</span><span>{html.escape(str(val))}</span></div>', unsafe_allow_html=True)
        h.show_df(seats[["seat_label", "seat_type", "Price"]].rename(columns={"seat_label": "Seat", "seat_type": "Category"}))
        c1, c2 = st.columns(2)
        c1.metric("Subtotal", h.money(total))
        c2.metric("Total", h.money(total))
    _nav(back=4, next_label="Continue to payment →", next_step=6)


def step_payment():
    s = _state()
    st.subheader("Step 6 · Payment")
    st.info(f"Amount due: **{h.money(s['total'])}** (payment amount always matches the booking total)", icon="💳")
    method = st.radio("Payment method", db.PAYMENT_METHODS, format_func=METHOD_ICON.get, horizontal=True)
    c1, c2, _ = st.columns([1, 1.6, 4])
    if c1.button("← Back", key="back_pay"):
        _go(5)
        st.rerun()
    if c2.button(f"Pay {h.money(s['total'])} & confirm", type="primary"):
        try:
            with st.spinner("Processing payment…"):
                time.sleep(0.7)
                res = db.create_booking(s["customer_id"], s["show_id"], s["seat_ids"], method)
            _go(7, result=res, method=method)
            st.rerun()
        except Exception as exc:
            st.error(db.friendly_error(exc), icon="❌")
            st.caption("The transaction was rolled back – nothing was charged. Go back and choose different seats.")


def step_done():
    s = _state()
    b = db.get_booking_details(s["result"]["booking_id"])
    pay = b["payment"]
    rows = [("Booking ID", f"#{b['booking_id']}"), ("Customer", b["customer_name"]), ("Movie", b["movie_title"]),
            ("Screen", b["screen_name"]), ("Show", f"{b['show_date']} {b['start_time']}"), ("Seats", b["seats"]),
            ("Amount Paid", h.money(pay["amount"])), ("Payment Method", pay["payment_method"]),
            ("Transaction Ref", pay["transaction_reference"])]
    body = "".join(f'<div class="cs-row"><span>{k}</span><span>{html.escape(str(v))}</span></div>' for k, v in rows)
    st.markdown(f'<div class="cs-confirm"><h2>BOOKING CONFIRMED ✓</h2>{body}</div>', unsafe_allow_html=True)
    st.success("Booking confirmed successfully. Tickets have been generated.", icon="✅")
    codes = [t["ticket_code"] for t in db.get_tickets(b["booking_id"])]
    st.caption("Ticket codes: " + " · ".join(codes))
    c1, c2, _ = st.columns([1.3, 1.3, 4])
    c1.button("🎫 View / download tickets", type="primary", on_click=h.goto, args=("Ticket",), kwargs={"ticket_booking_id": b["booking_id"]})
    if c2.button("➕ New booking"):
        _reset()
        st.rerun()
