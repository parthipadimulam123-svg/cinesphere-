import streamlit as st

import database as db
from utils import helpers as h
from views import cancellations


def render():
    h.page_header("Bookings", "Search, inspect and cancel bookings (history is never deleted)", "📒")
    df = db.get_view("vw_booking_details").sort_values("booking_id", ascending=False)
    c1, c2, c3, c4, c5 = st.columns([1, 1.4, 1.4, 1.2, 1.2])
    bid = c1.text_input("Booking ID", placeholder="e.g. 12")
    cust = c2.text_input("Customer", placeholder="name contains…")
    movie = c3.selectbox("Movie", ["All"] + sorted(df["movie_title"].unique()))
    day = c4.selectbox("Show date", ["All"] + sorted(df["show_date"].unique(), reverse=True))
    status = c5.selectbox("Status", ["All", "Confirmed", "Pending", "Cancelled"])
    if bid.strip():
        df = df[df["booking_id"].astype(str) == bid.strip().lstrip("#")]
    if cust:
        df = df[df["customer_name"].str.contains(cust, case=False, regex=False)]
    if movie != "All":
        df = df[df["movie_title"] == movie]
    if day != "All":
        df = df[df["show_date"] == day]
    if status != "All":
        df = df[df["booking_status"] == status]
    st.caption(f"{len(df)} booking(s) found")
    view = df.assign(**{"Show Time": df["show_date"] + " " + df["start_time"],
                        "Payment Status": df["payment_status"].map(h.status_label),
                        "Booking Status": df["booking_status"].map(h.status_label)})
    view = view.rename(columns={"booking_id": "Booking ID", "customer_name": "Customer", "movie_title": "Movie",
                                "seats": "Seats", "total_amount": "Amount ($)"})
    h.show_df(view[["Booking ID", "Customer", "Movie", "Show Time", "Seats", "Amount ($)", "Payment Status", "Booking Status"]])

    if df.empty:
        return
    st.subheader("Booking details")
    ids = df["booking_id"].tolist()[:300]
    pre = st.session_state.get("details_booking_id")
    sel = st.selectbox("Select booking", ids, index=ids.index(pre) if pre in ids else 0, format_func=lambda i: f"#{i}")
    b = db.get_booking_details(int(sel))
    with st.expander(f"View details · Booking #{sel}", expanded=True):
        c1, c2, c3 = st.columns(3)
        c1.markdown(f"**Customer**  \n{b['customer_name']}  \n{b['email']}")
        c2.markdown(f"**Show**  \n{b['movie_title']}  \n{b['screen_name']} · {b['show_date']} {b['start_time']}")
        c3.markdown(f"**Status**  \n{h.status_label(b['booking_status'])}  \nBooked {b['booking_datetime']}")
        h.show_df(b["seat_rows"])
        if b["payment"]:
            p = b["payment"]
            st.caption(f"Payment {p['transaction_reference']} · {p['payment_method']} · {h.money(p['amount'])} · {h.status_label(p['payment_status'])}")
    if b["booking_status"] != "Cancelled":
        with st.expander("❌ Cancel this booking"):
            cancellations.render_cancel_panel(int(sel), "bk")
