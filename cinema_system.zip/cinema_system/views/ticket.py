import streamlit.components.v1 as components
import streamlit as st

import database as db
from utils import helpers as h


def render():
    h.page_header("Digital Tickets", "View, print or download cinema tickets", "🎫")
    df = db.query_df("""SELECT booking_id, customer_name, movie_title, show_date, start_time, booking_status
                        FROM vw_booking_details WHERE booking_id IN (SELECT booking_id FROM ticket)
                        ORDER BY booking_id DESC LIMIT 300""")
    if df.empty:
        st.info("No tickets have been issued yet.")
        return
    labels = {int(r.booking_id): f"#{r.booking_id} · {r.customer_name} · {r.movie_title} · {r.show_date} {r.start_time}"
              + (" · CANCELLED" if r.booking_status == "Cancelled" else "") for r in df.itertuples()}
    ids = list(labels)
    pre = st.session_state.pop("ticket_booking_id", None)
    bid = st.selectbox("Select booking", ids, index=ids.index(pre) if pre in ids else 0, format_func=labels.get)
    tickets = db.get_tickets(bid)
    st.caption(f"{len(tickets)} ticket(s) · use your browser's print function on the downloaded HTML file to print.")
    for t in tickets:
        components.html(h.ticket_html(t), height=290)
        st.download_button(f"⬇️ Download ticket {t['seat']} (HTML)", h.ticket_html(t),
                           file_name=f"cinesphere_ticket_{t['ticket_code']}.html", mime="text/html", key=f"dl_{t['ticket_id']}")
