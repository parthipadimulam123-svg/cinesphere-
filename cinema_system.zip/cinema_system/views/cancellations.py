from datetime import datetime

import streamlit as st

import database as db
from utils import helpers as h

REASONS = ["Change of plans", "Schedule clash", "Unwell", "Booked wrong show", "Travel delay", "Other"]


def _policy_table(active_pct=None):
    rows = "".join(f"<tr><td>{label}</td><td>→</td><td><b>{pct}%</b>{' ◀ applies now' if pct == active_pct else ''}</td></tr>"
                   for _, pct, label in db.CANCEL_POLICY)
    st.markdown(f'<table class="cs-policy"><tr><th>Cancellation policy</th><th></th><th>Refund</th></tr>{rows}'
                f'<tr><td>After show start</td><td>→</td><td><b>Cancellation prohibited</b></td></tr></table>', unsafe_allow_html=True)


def render_cancel_panel(booking_id, key):
    """Quote + confirmation form, reused by the Bookings page and the Cancellations page."""
    quote = db.cancellation_quote(booking_id)
    b = db.get_booking_details(booking_id)
    c1, c2, c3 = st.columns(3)
    c1.metric("Time before show", f"{max(quote['hours_left'], 0):.1f} h" if quote["hours_left"] > 0 else "Started")
    c2.metric("Refund percentage", f"{quote['refund_pct']}%")
    c3.metric("Refund amount", h.money(quote["refund_amount"]), help=f"Amount paid: {h.money(quote['paid_amount'])}")
    _policy_table(quote["refund_pct"] if quote["eligible"] and quote["paid_amount"] else None)
    if not quote["eligible"]:
        st.error(quote["message"], icon="❌")
        return
    st.caption(f"Booking #{booking_id} · {b['movie_title']} · {b['seats']} · paid {h.money(quote['paid_amount'])}")
    reason = st.selectbox("Reason for cancellation *", REASONS, key=f"{key}_reason_{booking_id}")
    note = st.text_input("Additional details (optional)", key=f"{key}_note_{booking_id}") if reason == "Other" else ""
    ok = st.checkbox("I confirm I want to cancel this booking", key=f"{key}_ok_{booking_id}")
    with st.container(key=f"danger_cancel_{key}_{booking_id}"):
        if st.button("Confirm cancellation", disabled=not ok, key=f"{key}_btn_{booking_id}"):
            try:
                res = db.cancel_booking(booking_id, f"{reason}: {note}".strip(": ") if note else reason)
                h.flash("success", f"Booking cancelled successfully.  \nEligible refund: {h.money(res['refund_amount'])}")
                st.rerun()
            except Exception as exc:
                st.error(db.friendly_error(exc), icon="❌")


def render():
    h.page_header("Cancellations & Refunds", "Automatic refund calculation based on time remaining before the show", "↩️")
    tab_cancel, tab_hist = st.tabs(["❌ Cancel a booking", "🧾 Cancellation history"])
    with tab_cancel:
        incl_past = st.checkbox("Include bookings for shows that already started (to demonstrate the 'prohibited' rule)")
        df = db.get_view("vw_booking_details")
        df = df[df["booking_status"].isin(["Confirmed", "Pending"])]
        if not incl_past:
            df = df[(df["show_date"] + " " + df["start_time"]) > datetime.now().strftime("%Y-%m-%d %H:%M")]
        df = df.sort_values(["show_date", "start_time"]).head(300)
        if df.empty:
            st.info("No cancellable bookings.")
        else:
            labels = {int(r.booking_id): f"#{r.booking_id} · {r.customer_name} · {r.movie_title} · {r.show_date} {r.start_time} · {r.seats}"
                      for r in df.itertuples()}
            bid = st.selectbox("Booking ID", list(labels), format_func=labels.get)
            with st.container(border=True):
                render_cancel_panel(int(bid), "cx")
    with tab_hist:
        hist = db.get_cancellations()
        if hist.empty:
            st.info("No cancellations yet.")
        else:
            c1, c2, c3 = st.columns(3)
            c1.metric("Cancellations", len(hist))
            c2.metric("Total refunded", h.money(hist["refund_amount"].sum()))
            c3.metric("No-refund cancellations", int((hist["refund_amount"] == 0).sum()))
            h.show_df(hist.rename(columns={"cancellation_id": "ID", "booking_id": "Booking", "customer": "Customer", "movie": "Movie",
                                           "cancellation_datetime": "Cancelled At", "reason": "Reason", "refund_percentage": "Refund %",
                                           "refund_amount": "Refund ($)", "refund_status": "Refund Status"}))
