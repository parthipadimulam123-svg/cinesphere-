import plotly.express as px
import streamlit as st

import database as db
from utils import helpers as h


def _chart(fig, height=340):
    with st.container(border=True):
        st.plotly_chart(h.style_fig(fig, height))


def render():
    h.page_header("Reports & Analytics", "Operational and financial insight powered by SQL views", "📈")
    tabs = st.tabs(["🎞️ Show Occupancy", "🏆 Movie Performance", "🏛️ Screen Utilization",
                    "🍿 Concessions", "↩️ Cancellations", "💰 Revenue"])

    with tabs[0]:
        st.caption("View: vw_show_occupancy (INNER JOIN + LEFT JOIN on a grouped sub-query)")
        d = db.get_view("vw_show_occupancy")
        d = d[d["status"] != "Cancelled"].sort_values(["show_date", "start_time"])
        h.show_df(d[["show_id", "movie_title", "screen_name", "show_date", "start_time", "seats_sold", "capacity", "available_seats", "occupancy_pct"]]
                  .rename(columns={"show_id": "Show ID", "movie_title": "Movie", "screen_name": "Screen", "show_date": "Date",
                                   "start_time": "Start", "seats_sold": "Seats Sold", "capacity": "Capacity",
                                   "available_seats": "Available", "occupancy_pct": "Occupancy %"}),
                  column_config={"Occupancy %": st.column_config.ProgressColumn(min_value=0, max_value=100, format="%.1f%%")})
        d = d.assign(label="#" + d["show_id"].astype(str) + " " + d["movie_title"] + " " + d["show_date"].str[5:])
        _chart(px.bar(d.tail(30), x="label", y="occupancy_pct", color="screen_name", title="Occupancy % by show (latest 30)",
                      labels={"label": "", "occupancy_pct": "Occupancy %"}), 380)

    with tabs[1]:
        st.caption("View: vw_movie_performance (LEFT JOIN + AVG + correlated sub-query for revenue)")
        d = db.get_view("vw_movie_performance").sort_values("ticket_revenue", ascending=False)
        h.show_df(d.drop(columns=["movie_id"]).rename(columns={"title": "Movie", "genre": "Genre", "total_shows": "Shows",
                  "tickets_sold": "Tickets Sold", "avg_occupancy_pct": "Avg Occupancy %", "ticket_revenue": "Ticket Revenue ($)"}))
        _chart(px.bar(d, x="ticket_revenue", y="title", orientation="h", title="Top movies by ticket revenue",
                      labels={"title": "", "ticket_revenue": "Revenue ($)"}).update_yaxes(autorange="reversed"))

    with tabs[2]:
        st.caption("View: vw_screen_utilization (scheduled hours computed with julianday())")
        d = db.get_view("vw_screen_utilization")
        h.show_df(d.drop(columns=["screen_id"]).rename(columns={"screen_name": "Screen", "capacity": "Capacity", "total_shows": "Shows",
                  "scheduled_hours": "Scheduled Hours", "avg_occupancy_pct": "Avg Occupancy %", "ticket_revenue": "Revenue ($)"}))
        c1, c2 = st.columns(2)
        with c1:
            _chart(px.bar(d, x="screen_name", y="scheduled_hours", title="Scheduled hours by screen", labels={"screen_name": "", "scheduled_hours": "Hours"}))
        with c2:
            _chart(px.bar(d, x="screen_name", y="avg_occupancy_pct", title="Average occupancy % by screen", labels={"screen_name": "", "avg_occupancy_pct": "%"}))

    with tabs[3]:
        st.caption("View: vw_concession_performance (LEFT JOIN, SUM(quantity × unit_price))")
        d = db.get_view("vw_concession_performance").sort_values("sales_revenue", ascending=False)
        c1, c2 = st.columns(2)
        c1.metric("Top selling item", d.iloc[0]["item_name"] if d["quantity_sold"].max() else "—")
        c2.metric("Total concession revenue", h.money(d["sales_revenue"].sum()))
        h.show_df(d[["item_name", "category", "quantity_sold", "sales_revenue", "stock_quantity"]].rename(columns={
            "item_name": "Item", "category": "Category", "quantity_sold": "Quantity Sold", "sales_revenue": "Sales Revenue ($)", "stock_quantity": "Stock Left"}))
        _chart(px.bar(d, x="item_name", y="quantity_sold", color="category", title="Quantity sold by item", labels={"item_name": "", "quantity_sold": "Units"}))

    with tabs[4]:
        st.caption("View: vw_cancellation_summary (multiple LEFT JOINs, COUNT DISTINCT, NULLIF)")
        d = db.get_view("vw_cancellation_summary")
        h.show_df(d.drop(columns=["movie_id"]).rename(columns={"title": "Movie", "total_bookings": "Bookings", "cancellations": "Cancellations",
                  "cancellation_rate_pct": "Cancellation Rate %", "refund_amount": "Refund Amount ($)"}))
        c1, c2 = st.columns(2)
        with c1:
            _chart(px.bar(d, x="title", y="cancellation_rate_pct", title="Cancellation rate % by movie", labels={"title": "", "cancellation_rate_pct": "%"}))
        with c2:
            dd = d[d["cancellations"] > 0]
            _chart(px.pie(dd, names="title", values="cancellations", hole=0.5, title="Share of cancellations"))
        hist = db.get_cancellations()
        if not hist.empty:
            st.markdown("**Refund tiers applied**")
            tiers = hist.groupby("refund_percentage", as_index=False).agg(Cancellations=("cancellation_id", "count"), Refunded=("refund_amount", "sum"))
            h.show_df(tiers.rename(columns={"refund_percentage": "Refund %", "Refunded": "Refunded ($)"}))

    with tabs[5]:
        st.caption("View: vw_revenue_summary → Net Revenue = Ticket Revenue + Concession Revenue − Refund Amount")
        r = db.get_view("vw_revenue_summary").iloc[0]
        h.kpi_row([("Ticket Revenue", h.money(r["ticket_revenue"]), "🎟️", "payments collected"),
                   ("Concession Revenue", h.money(r["concession_revenue"]), "🍿", "POS sales"),
                   ("Refund Amount", h.money(r["refund_amount"]), "↩️", "refunds processed"),
                   ("Net Revenue", h.money(r["net_revenue"]), "💰", "tickets + concessions − refunds")])
        st.write("")
        daily = db.get_view("vw_daily_revenue").sort_values("revenue_date")
        c1, c2 = st.columns(2)
        with c1:
            _chart(px.line(daily, x="revenue_date", y="net_revenue", markers=True, title="Daily net revenue", labels={"revenue_date": "", "net_revenue": "$"}))
        with c2:
            _chart(px.pie(names=["Ticket", "Concession"], values=[r["ticket_revenue"], r["concession_revenue"]], hole=0.55, title="Revenue breakdown (gross)"))
        c3, c4 = st.columns(2)
        movies = db.get_view("vw_movie_performance")
        screens = db.get_view("vw_screen_utilization")
        with c3:
            _chart(px.bar(movies.sort_values("ticket_revenue", ascending=False), x="title", y="ticket_revenue", title="Revenue by movie", labels={"title": "", "ticket_revenue": "$"}))
        with c4:
            _chart(px.bar(screens, x="screen_name", y="ticket_revenue", title="Revenue by screen", labels={"screen_name": "", "ticket_revenue": "$"}))
