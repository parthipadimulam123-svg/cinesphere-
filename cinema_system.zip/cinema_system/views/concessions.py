import html

import pandas as pd
import streamlit as st

import database as db
from utils import helpers as h

ICON = {"Popcorn": "🍿", "Nachos": "🧀", "Hot Dog": "🌭", "Soft Drink": "🥤", "Water": "💧", "Chocolate": "🍫",
        "Ice Cream": "🍦", "Combo Meal": "🍱"}


def render():
    h.page_header("Concessions", "Point-of-sale for snacks and drinks – stock updates automatically", "🍿")
    cart = st.session_state.setdefault("cart", {})
    items = db.get_items()
    by_id = {int(r.item_id): r for r in items.itertuples()}
    left, right = st.columns([3, 2])

    with left:
        st.subheader("Menu")
        for i, row in enumerate(items.itertuples()):
            if i % 2 == 0:
                cols = st.columns(2)
            with cols[i % 2], st.container(border=True):
                in_cart = cart.get(int(row.item_id), 0)
                st.markdown(f"<div class='cs-item'><h4 style='margin:0'>{ICON.get(row.item_name, '🍽️')} {html.escape(row.item_name)}</h4>"
                            f"<span class='meta' style='color:#9aa6c4;font-size:.8rem'>{row.category} · stock {row.stock_quantity}</span>"
                            f"<div class='price'>{h.money(row.unit_price)}</div></div>", unsafe_allow_html=True)
                q = st.number_input("Quantity", 0, 1000, 1, key=f"q_{row.item_id}", label_visibility="collapsed")
                if st.button("Add to cart", key=f"add_{row.item_id}"):
                    if q <= 0:
                        st.error("Quantity must be greater than zero.", icon="❌")
                    elif in_cart + q > row.stock_quantity:
                        st.error(f"Insufficient stock – only {row.stock_quantity - in_cart} more {row.item_name} available.", icon="❌")
                    else:
                        cart[int(row.item_id)] = in_cart + int(q)
                        st.rerun()

    with right, st.container(border=True):
        st.subheader("🛒 Cart")
        if not cart:
            st.info("The cart is empty. Add items from the menu.")
        else:
            rows = [{"Item": by_id[i].item_name, "Price": by_id[i].unit_price, "Quantity": q,
                     "Subtotal": round(by_id[i].unit_price * q, 2)} for i, q in cart.items()]
            h.show_df(pd.DataFrame(rows))
            c1, c2 = st.columns(2)
            c1.metric("Total Items", sum(cart.values()))
            c2.metric("Grand Total", h.money(sum(r["Subtotal"] for r in rows)))
            customers = db.query_df("SELECT customer_id, full_name FROM customer ORDER BY full_name")
            names = {0: "Walk-in customer"} | {int(r.customer_id): r.full_name for r in customers.itertuples()}
            cust = st.selectbox("Customer (optional)", list(names), format_func=names.get)
            b1, b2 = st.columns(2)
            with st.container(key="danger_clear_cart"):
                if b1.button("Clear Cart"):
                    cart.clear()
                    st.rerun()
            if b2.button("Complete Sale", type="primary"):
                try:
                    sale_id, total = db.complete_concession_sale(dict(cart), cust or None)
                    cart.clear()
                    h.flash("success", f"Sale #{sale_id} completed – {h.money(total)} collected. Stock updated.")
                    st.rerun()
                except Exception as exc:
                    st.error(db.friendly_error(exc), icon="❌")
