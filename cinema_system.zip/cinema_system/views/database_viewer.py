import streamlit as st

import database as db
from utils import helpers as h


def render():
    h.page_header("Database Explorer", "Inspect tables, views, schema and test the database constraints", "🗄️")
    tab_tables, tab_lab = st.tabs(["📚 Tables & Views", "🧪 Constraint Lab"])

    with tab_tables:
        names = db.list_tables()
        name = st.selectbox("Table / view", names, index=names.index("customer") if "customer" in names else 0)
        data = db.table_data(name)
        c1, c2 = st.columns(2)
        c1.metric("Rows", f"{len(data):,}")
        c2.metric("Columns", len(data.columns))
        st.markdown("**Current records**")
        h.show_df(data.head(500))
        with st.expander("🧱 Schema / table description", expanded=True):
            schema = db.table_schema(name).rename(columns={"cid": "#", "name": "Column", "type": "Type", "notnull": "Not Null",
                                                           "dflt_value": "Default", "pk": "PK"})
            h.show_df(schema)
            sql = db.query_one("SELECT sql FROM sqlite_master WHERE name = ?", (name,))
            if sql and sql["sql"]:
                st.code(sql["sql"], language="sql")

    with tab_lab:
        st.caption("Each test attempts an illegal write inside a transaction that is always rolled back – no data changes.")
        tests = [("duplicate_seat", "🪑 Double-book a seat", "Insert a second ACTIVE booking_seat for an already booked seat (UNIQUE show_id + seat_id)."),
                 ("overlap", "🗓️ Overlapping show", "Insert a show at the same screen/date/time as an existing show (trigger)."),
                 ("negative_price", "💲 Negative price", "Insert a concession item with unit_price = -5 (CHECK constraint)."),
                 ("refund_cap", "↩️ Refund above payment", "Insert a refund bigger than the original payment (trigger).")]
        for key, title, desc in tests:
            with st.container(border=True):
                c1, c2 = st.columns([3, 1])
                c1.markdown(f"**{title}**  \n<span style='color:#9aa6c4'>{desc}</span>", unsafe_allow_html=True)
                if c2.button("Run test", key=f"lab_{key}"):
                    friendly, raw = db.run_constraint_demo(key)
                    st.error(friendly, icon="🛡️")
                    if raw:
                        st.code(raw, language="text")
