import plotly.express as px
import streamlit as st

import database as db
from utils import helpers as h


def render():
    h.page_header("CineSphere Dashboard", "Real-time overview of cinema operations", "📊")
    k = db.get_dashboard_kpis()
    h.kpi_row([("Today's Shows", k["todays_shows"], "🎞️", "scheduled today"),
               ("Tickets Sold", f"{k['tickets_sold']:,}", "🎟️", "active tickets, all shows"),
               ("Today's Revenue", h.money(k["todays_revenue"]), "💰", "tickets + concessions"),
               ("Available Seats", f"{k['available_seats']:,}", "💺", "remaining shows today"),
               ("Total Bookings", f"{k['total_bookings']:,}", "📒", "all time"),
               ("Cancellation Rate", f"{k['cancellation_rate']}%", "↩️", "of all bookings")])
    st.write("")

    movies = db.get_view("vw_movie_performance")
    screens = db.get_view("vw_screen_utilization")
    items = db.get_view("vw_concession_performance")
    trend = db.query_df("""SELECT date(booking_datetime) AS day, COUNT(*) AS bookings
                           FROM booking GROUP BY date(booking_datetime) ORDER BY day""")
    status = db.query_df("SELECT booking_status AS status, COUNT(*) AS bookings FROM booking GROUP BY booking_status")

    c1, c2 = st.columns(2)
    with c1, st.container(border=True):
        top = movies.sort_values("ticket_revenue", ascending=False)
        fig = px.bar(top, x="title", y="ticket_revenue", title="Revenue by Movie", text_auto=".2s",
                     labels={"title": "", "ticket_revenue": "Revenue ($)"})
        st.plotly_chart(h.style_fig(fig))
    with c2, st.container(border=True):
        fig = px.line(trend, x="day", y="bookings", markers=True, title="Booking Trend (bookings per day)",
                      labels={"day": "", "bookings": "Bookings"})
        st.plotly_chart(h.style_fig(fig))

    c3, c4, c5 = st.columns(3)
    with c3, st.container(border=True):
        fig = px.bar(screens, x="screen_name", y="avg_occupancy_pct", title="Seat Occupancy by Screen (%)",
                     text_auto=".1f", labels={"screen_name": "", "avg_occupancy_pct": "Avg occupancy %"})
        st.plotly_chart(h.style_fig(fig))
    with c4, st.container(border=True):
        fig = px.pie(items[items["sales_revenue"] > 0], names="item_name", values="sales_revenue", hole=0.55,
                     title="Concession Sales Breakdown")
        st.plotly_chart(h.style_fig(fig))
    with c5, st.container(border=True):
        fig = px.pie(status, names="status", values="bookings", hole=0.55, title="Booking Status",
                     color="status", color_discrete_map={"Confirmed": "#22c55e", "Pending": "#F5B301", "Cancelled": "#ef4444"})
        st.plotly_chart(h.style_fig(fig))

    with st.container(border=True):
        best = movies.sort_values("tickets_sold", ascending=True).tail(7)
        fig = px.bar(best, x="tickets_sold", y="title", orientation="h", title="Top Performing Movies (tickets sold)",
                     text_auto=True, labels={"title": "", "tickets_sold": "Tickets"})
        st.plotly_chart(h.style_fig(fig, 300))

    st.subheader("🎞️ Upcoming Shows")
    st.caption("Next shows still open for booking, with live occupancy from the vw_show_occupancy view.")
    up = db.get_shows(open_only=True).head(12)
    table = up.assign(**{"Start Time": up["show_date"] + " " + up["start_time"], "Status": up["status"].map(h.status_label)})
    table = table.rename(columns={"movie_title": "Movie", "screen_name": "Screen", "available_seats": "Available Seats",
                                  "occupancy_pct": "Occupancy %"})[["Movie", "Screen", "Start Time", "Available Seats", "Occupancy %", "Status"]]
    h.show_df(table, column_config={"Occupancy %": st.column_config.ProgressColumn("Occupancy %", min_value=0, max_value=100, format="%.0f%%")})
