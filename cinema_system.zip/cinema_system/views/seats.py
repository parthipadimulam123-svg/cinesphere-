import streamlit as st

import database as db
from utils import helpers as h


def render():
    h.page_header("Seat Availability", "Live cinema seat map – pick a show and select seats", "💺")
    shows = db.get_shows(open_only=True)
    if shows.empty:
        st.info("There are no upcoming shows.")
        return
    c1, c2 = st.columns([1, 2])
    days = sorted(shows["show_date"].unique())
    day = c1.selectbox("Date", ["All dates"] + days)
    if day != "All dates":
        shows = shows[shows["show_date"] == day]
    labels = {int(r.show_id): f"{r.movie_title} · {r.screen_name} · {r.show_date} {r.start_time}" for r in shows.itertuples()}
    show_id = c2.selectbox("Show", list(labels), format_func=labels.get)
    s = shows[shows["show_id"] == show_id].iloc[0]
    h.kpi_row([("Movie", s["movie_title"], "🎬", s["screen_name"]), ("Time", f"{s['start_time']}", "🕒", s["show_date"]),
               ("Available", int(s["available_seats"]), "🟩", f"of {int(s['capacity'])} seats"),
               ("Occupancy", f"{s['occupancy_pct']}%", "📈", h.status_label(s["status"]))])
    st.write("")
    with st.container(border=True):
        h.render_seat_map(int(show_id), "avail")
    st.caption("Tip: to reserve the selected seats, use **Customer Booking** (a customer account is required).")
