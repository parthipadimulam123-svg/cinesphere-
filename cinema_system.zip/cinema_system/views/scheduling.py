from datetime import date, datetime, time

import streamlit as st

import database as db
from utils import helpers as h


def render():
    h.page_header("Show Scheduling", "Plan screenings – overlaps on the same screen are blocked automatically", "🗓️")
    tab_list, tab_add, tab_manage = st.tabs(["📋 Schedule", "➕ Schedule a Show", "🛠️ Manage Show"])

    with tab_list:
        shows = db.get_shows()
        c1, c2, c3, c4 = st.columns(4)
        day = c1.selectbox("Date", ["All dates"] + sorted(shows["show_date"].unique()))
        movie = c2.selectbox("Movie", ["All movies"] + sorted(shows["movie_title"].unique()))
        screen = c3.selectbox("Screen", ["All screens"] + sorted(shows["screen_name"].unique()))
        status = c4.multiselect("Status", ["Upcoming", "Now Showing", "Completed", "Cancelled"])
        if day != "All dates":
            shows = shows[shows["show_date"] == day]
        if movie != "All movies":
            shows = shows[shows["movie_title"] == movie]
        if screen != "All screens":
            shows = shows[shows["screen_name"] == screen]
        if status:
            shows = shows[shows["status"].isin(status)]
        st.caption(f"{len(shows)} show(s)")
        view = shows.assign(status=shows["status"].map(h.status_label)).rename(columns={
            "show_id": "Show ID", "movie_title": "Movie", "screen_name": "Screen", "show_date": "Date", "start_time": "Start",
            "end_time": "End", "ticket_price": "Price ($)", "status": "Status", "occupancy_pct": "Occupancy %"})
        h.show_df(view[["Show ID", "Movie", "Screen", "Date", "Start", "End", "Price ($)", "Status", "Occupancy %"]],
                  column_config={"Occupancy %": st.column_config.ProgressColumn(min_value=0, max_value=100, format="%.0f%%")})

    with tab_add:
        movies = db.get_movies()
        movies = movies[movies["status"] != "Archived"]
        screens = db.get_screens()
        screens = screens[screens["status"] == "Active"]
        mlabels = {int(r.movie_id): f"{r.title} · {r.duration_minutes} min" for r in movies.itertuples()}
        slabels = {int(r.screen_id): f"{r.screen_name} · {r.screen_type} · {r.capacity} seats" for r in screens.itertuples()}
        with st.container(border=True):
            c1, c2 = st.columns(2)
            movie_id = c1.selectbox("Movie", list(mlabels), format_func=mlabels.get)
            screen_id = c2.selectbox("Screen", list(slabels), format_func=slabels.get)
            c3, c4, c5, c6 = st.columns(4)
            show_date = c3.date_input("Date", date.today(), min_value=date.today())
            start = c4.time_input("Start time", time(18, 0), step=300)
            buffer = c5.selectbox("Cleaning buffer (min)", [0, 10, 15, 20, 30], index=2)
            price = c6.number_input("Ticket price ($)", 0.0, 500.0, 12.0, 0.5)
            duration = int(movies[movies["movie_id"] == movie_id]["duration_minutes"].iloc[0])
            try:
                end = db.calc_end_time(start.strftime("%H:%M"), duration, buffer)
                st.info(f"End time = {start.strftime('%H:%M')} + {duration} min + {buffer} min buffer → **{end}**", icon="⏱️")
                clash = db.find_overlap(screen_id, show_date.isoformat(), start.strftime("%H:%M"), end)
                if clash:
                    st.warning(f"Preview: schedule conflict with '{clash['title']}' ({clash['start_time']}–{clash['end_time']}).", icon="⚠️")
            except Exception as exc:
                st.warning(db.friendly_error(exc), icon="⚠️")
            if st.button("Schedule show", type="primary"):
                try:
                    db.add_show(movie_id, screen_id, show_date, start.strftime("%H:%M"), price, buffer)
                    h.flash("success", "Show scheduled successfully.")
                    st.rerun()
                except Exception as exc:
                    st.error(db.friendly_error(exc), icon="❌")
        st.caption("Rule: new_start < existing_end AND new_end > existing_start on the same screen/date → rejected "
                   "(checked in Python and again by an SQLite trigger).")

    with tab_manage:
        shows = db.get_shows(open_only=True)
        if shows.empty:
            st.info("No upcoming shows to manage.")
            return
        labels = {int(r.show_id): f"#{r.show_id} · {r.movie_title} · {r.screen_name} · {r.show_date} {r.start_time}" for r in shows.itertuples()}
        sid = st.selectbox("Select show", list(labels), format_func=labels.get)
        cur = shows[shows["show_id"] == sid].iloc[0]
        st.caption(f"Seats sold: {cur['seats_sold']} / {cur['capacity']} · Status: {cur['status']}")
        c1, c2 = st.columns([1, 1])
        new_price = c1.number_input("Ticket price ($)", 0.0, 500.0, float(cur["ticket_price"]), 0.5, key=f"np_{sid}")
        c2.write("")
        if c2.button("Update price", key=f"up_{sid}"):
            try:
                db.update_show_price(sid, new_price)
                h.flash("success", "Ticket price updated.")
                st.rerun()
            except Exception as exc:
                st.error(db.friendly_error(exc), icon="❌")
        with st.container(key=f"danger_show_{sid}"):
            d1, d2 = st.columns(2)
            if d1.button("Cancel show", key=f"cs_{sid}"):
                try:
                    db.cancel_show(sid)
                    h.flash("success", "Show cancelled.")
                    st.rerun()
                except Exception as exc:
                    st.error(db.friendly_error(exc), icon="❌")
            if d2.button("Delete show", key=f"ds_{sid}"):
                try:
                    db.delete_show(sid)
                    h.flash("success", "Show deleted.")
                    st.rerun()
                except Exception as exc:
                    st.error(db.friendly_error(exc), icon="❌")
