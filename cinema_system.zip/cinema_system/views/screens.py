import streamlit as st

import database as db
from utils import helpers as h

TYPES = ["Standard", "IMAX", "Premium", "VIP"]
STATUSES = ["Active", "Maintenance", "Closed"]


def _layout_inputs(prefix, rows=6, per_row=10, prem=2, vip=1):
    c1, c2, c3, c4 = st.columns(4)
    r = c1.number_input("Rows (A…)", 0, 26, rows, key=f"{prefix}_rows")
    p = c2.number_input("Seats per row", 0, 30, per_row, key=f"{prefix}_per")
    pr = c3.number_input("Premium rows (from back)", 0, 26, prem, key=f"{prefix}_prem")
    vp = c4.number_input("VIP rows (at the back)", 0, 26, vip, key=f"{prefix}_vip")
    st.caption(f"Capacity will be **{r * p}** seats · Rows A–{chr(64 + r) if r else '—'} · seat numbers 1–{p}")
    return int(r), int(p), int(pr), int(vp)


def render():
    h.page_header("Screens & Seats", "Configure auditoriums, capacity and seat categories", "🏛️")
    tab_view, tab_add, tab_manage = st.tabs(["👁️ Screens", "➕ Add Screen", "🛠️ Edit & Manage Seats"])
    screens = db.get_screens()

    with tab_view:
        st.caption("Seat colours: 🟩 Standard · 🟨 Premium · 🟪 VIP")
        cols = st.columns(2)
        for i, sc in enumerate(screens.itertuples()):
            with cols[i % 2], st.container(border=True):
                st.markdown(f"**{sc.screen_name}** &nbsp; {h.status_label(sc.status)} &nbsp; `{sc.screen_type}`")
                st.caption(f"Capacity {sc.capacity} · Standard {sc.standard_seats} · Premium {sc.premium_seats} · VIP {sc.vip_seats}")
                h.render_mini_seatmap(sc.screen_id)
        h.show_df(screens.rename(columns={"screen_id": "ID", "screen_name": "Screen", "screen_type": "Type", "capacity": "Capacity",
                                          "status": "Status", "standard_seats": "Standard", "premium_seats": "Premium", "vip_seats": "VIP"}))

    with tab_add:
        st.caption("Seats are generated automatically (e.g. rows A–F × seats 1–10 → A1, A2 … F10).")
        with st.container(border=True):
            c1, c2 = st.columns(2)
            name = c1.text_input("Screen name *", placeholder="Screen 5")
            stype = c2.selectbox("Screen type", TYPES)
            r, p, pr, vp = _layout_inputs("new_screen")
            if st.button("Create screen & generate seats", type="primary"):
                try:
                    db.create_screen(name, stype, r, p, pr, vp)
                    h.flash("success", f"{name.strip()} created with {r * p} seats.")
                    st.rerun()
                except Exception as exc:
                    st.error(db.friendly_error(exc), icon="❌")

    with tab_manage:
        labels = {int(s.screen_id): f"{s.screen_name} ({s.screen_type})" for s in screens.itertuples()}
        sid = st.selectbox("Select screen", list(labels), format_func=labels.get)
        cur = screens[screens["screen_id"] == sid].iloc[0]
        with st.container(border=True):
            st.markdown("##### Screen details")
            c1, c2, c3 = st.columns(3)
            name = c1.text_input("Name", cur["screen_name"], key=f"sn_{sid}")
            stype = c2.selectbox("Type", TYPES, TYPES.index(cur["screen_type"]), key=f"st_{sid}")
            status = c3.selectbox("Status", STATUSES, STATUSES.index(cur["status"]), key=f"ss_{sid}")
            if st.button("Save screen", type="primary", key=f"savesc_{sid}"):
                try:
                    db.update_screen(sid, name, stype, status)
                    h.flash("success", "Screen updated successfully.")
                    st.rerun()
                except Exception as exc:
                    st.error(db.friendly_error(exc), icon="❌")
        with st.container(border=True):
            st.markdown("##### Seat layout")
            h.render_mini_seatmap(sid)
            st.markdown("**Change a row's category**")
            rows = db.query_df("SELECT DISTINCT row_label FROM seat WHERE screen_id = ? ORDER BY row_label", (sid,))["row_label"].tolist()
            c1, c2, c3 = st.columns([1, 1, 1])
            row = c1.selectbox("Row", rows, key=f"row_{sid}")
            seat_type = c2.selectbox("Seat type", ["Standard", "Premium", "VIP"], key=f"rt_{sid}")
            c3.write("")
            if c3.button("Apply to row", key=f"apply_{sid}"):
                db.set_row_type(sid, row, seat_type)
                h.flash("success", f"Row {row} is now {seat_type}.")
                st.rerun()
            with st.expander("♻️ Regenerate all seats (only if no bookings exist)"):
                r, p, pr, vp = _layout_inputs(f"regen_{sid}")
                if st.button("Regenerate seats", key=f"regen_btn_{sid}"):
                    try:
                        db.regenerate_seats(sid, r, p, pr, vp)
                        h.flash("success", f"Seats regenerated – capacity is now {r * p}.")
                        st.rerun()
                    except Exception as exc:
                        st.error(db.friendly_error(exc), icon="❌")
        with st.expander("🗑️ Delete screen"):
            st.warning("A screen can only be deleted if no shows reference it.", icon="⚠️")
            ok = st.checkbox("I understand", key=f"delchk_{sid}")
            with st.container(key=f"danger_screen_{sid}"):
                if st.button("Delete screen", disabled=not ok, key=f"delsc_{sid}"):
                    try:
                        db.delete_screen(sid)
                        h.flash("success", "Screen deleted.")
                        st.rerun()
                    except Exception as exc:
                        st.error(db.friendly_error(exc), icon="❌")
