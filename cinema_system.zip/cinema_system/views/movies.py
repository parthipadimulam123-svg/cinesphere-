from datetime import date

import pandas as pd
import streamlit as st

import database as db
from utils import helpers as h

GENRES = ["Action", "Adventure", "Animation", "Comedy", "Drama", "Fantasy", "Horror", "Mystery", "Romance", "Sci-Fi", "Thriller"]
LANGS = ["English", "Hindi", "Telugu", "Tamil", "Spanish", "French", "Other"]
RATINGS = ["G", "PG", "PG-13", "R", "NC-17"]
STATUSES = ["Now Showing", "Coming Soon", "Archived"]


def _pick(options, value):
    return options.index(value) if value in options else 0


def _fields(prefix, m=None):
    m = m or {}
    title = st.text_input("Title *", m.get("title", ""), key=f"{prefix}_title")
    c1, c2, c3 = st.columns(3)
    genre = c1.selectbox("Genre *", GENRES, _pick(GENRES, m.get("genre")), key=f"{prefix}_genre")
    duration = c2.number_input("Duration (minutes) *", 0, 600, int(m.get("duration_minutes", 120)), key=f"{prefix}_dur")
    language = c3.selectbox("Language *", LANGS, _pick(LANGS, m.get("language")), key=f"{prefix}_lang")
    c4, c5, c6 = st.columns(3)
    rating = c4.selectbox("Rating", RATINGS, _pick(RATINGS, m.get("rating", "PG-13")), key=f"{prefix}_rating")
    release = c5.date_input("Release date", date.fromisoformat(m["release_date"]) if m.get("release_date") else date.today(),
                            key=f"{prefix}_rel")
    status = c6.selectbox("Status", STATUSES, _pick(STATUSES, m.get("status")), key=f"{prefix}_status")
    return {"title": title, "genre": genre, "duration_minutes": duration, "language": language,
            "rating": rating, "release_date": release, "status": status}


def render():
    h.page_header("Movies", "Manage the film catalogue: search, add, edit and remove movies", "🎬")
    tab_view, tab_add, tab_edit = st.tabs(["🔎 Browse & Search", "➕ Add Movie", "✏️ Edit / Delete"])
    movies = db.get_movies()

    with tab_view:
        c1, c2, c3 = st.columns([2, 1, 1])
        q = c1.text_input("Search title", placeholder="e.g. Horizon")
        genre = c2.selectbox("Genre", ["All"] + sorted(movies["genre"].unique()))
        lang = c3.selectbox("Language", ["All"] + sorted(movies["language"].unique()))
        view = movies
        if q:
            view = view[view["title"].str.contains(q, case=False, regex=False)]
        if genre != "All":
            view = view[view["genre"] == genre]
        if lang != "All":
            view = view[view["language"] == lang]
        st.caption(f"{len(view)} movie(s) found")
        view = view.assign(status=view["status"].map(h.status_label)).rename(columns={
            "movie_id": "ID", "title": "Title", "genre": "Genre", "duration_minutes": "Duration (min)",
            "language": "Language", "rating": "Rating", "release_date": "Release Date", "status": "Status"})
        h.show_df(view)

    with tab_add:
        st.caption("Fields marked * are mandatory. Duration must be greater than 0.")
        with st.container(border=True):
            data = _fields("add_movie")
            if st.button("Add Movie", type="primary"):
                try:
                    db.save_movie(data)
                    h.flash("success", f"Movie '{data['title'].strip()}' added successfully.")
                    st.rerun()
                except Exception as exc:
                    st.error(db.friendly_error(exc), icon="❌")

    with tab_edit:
        labels = {int(r.movie_id): f"{r.title} ({r.language})" for r in movies.itertuples()}
        movie_id = st.selectbox("Select movie", list(labels), format_func=labels.get)
        current = movies[movies["movie_id"] == movie_id].iloc[0].to_dict()
        with st.container(border=True):
            data = _fields(f"edit_movie_{movie_id}", current)
            if st.button("Save changes", type="primary", key=f"save_{movie_id}"):
                try:
                    db.save_movie(data, movie_id)
                    h.flash("success", "Movie updated successfully.")
                    st.rerun()
                except Exception as exc:
                    st.error(db.friendly_error(exc), icon="❌")
        st.markdown("##### Delete movie")
        st.warning(f"You are about to permanently delete **{current['title']}**. This cannot be undone. "
                   "Movies with scheduled shows are protected by foreign keys.", icon="⚠️")
        confirm = st.checkbox("I understand and want to delete this movie", key=f"confirm_del_{movie_id}")
        with st.container(key=f"danger_movie_{movie_id}"):
            if st.button("🗑️ Delete movie", disabled=not confirm):
                try:
                    db.delete_movie(movie_id)
                    h.flash("success", f"'{current['title']}' deleted.")
                    st.rerun()
                except Exception as exc:
                    st.error(db.friendly_error(exc), icon="❌")
