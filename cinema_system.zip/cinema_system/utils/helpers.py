"""Shared UI helpers: flash messages, tables, charts, seat map, ticket rendering."""
import html

import streamlit as st

import database as db
from utils import styles

PALETTE = ["#F5B301", "#60a5fa", "#22c55e", "#a855f7", "#f97316", "#14b8a6", "#e879f9", "#94a3b8"]
SEAT_EMOJI = {"Standard": "🟩", "Premium": "🟨", "VIP": "🟪"}
STATUS_ICON = {"Upcoming": "🔵", "Now Showing": "🟢", "Completed": "⚪", "Cancelled": "🔴",
               "Paid": "🟢", "Pending": "🟡", "Refunded": "🟣", "Failed": "🔴",
               "Confirmed": "🟢", "Active": "🟢", "Maintenance": "🟠", "Closed": "🔴",
               "Coming Soon": "🟡", "Archived": "⚪", "Processed": "🟢", "None": "⚪"}


def money(value):
    return f"${float(value or 0):,.2f}"


def status_label(status):
    return f"{STATUS_ICON.get(status, '⚪')} {status}"


# ---- flash messages survive st.rerun() -------------------------------------------------
def flash(kind, message):
    st.session_state.setdefault("_flash", []).append((kind, message))


def show_flash():
    icons = {"success": "✅", "error": "❌", "warning": "⚠️", "info": "ℹ️"}
    for kind, message in st.session_state.pop("_flash", []):
        getattr(st, kind)(message, icon=icons[kind])


def page_header(title, subtitle, icon="🎬"):
    st.markdown(f'<div class="cs-header"><h1>{icon} {html.escape(title)}</h1><p>{html.escape(subtitle)}</p></div>',
                unsafe_allow_html=True)
    show_flash()


def show_df(df, **kwargs):
    """st.dataframe that works on both old and new Streamlit width APIs."""
    try:
        st.dataframe(df, width="stretch", hide_index=True, **kwargs)
    except Exception:
        st.dataframe(df, use_container_width=True, hide_index=True, **kwargs)


def style_fig(fig, height=330):
    fig.update_layout(template="plotly_dark", height=height, paper_bgcolor="rgba(0,0,0,0)",
                      plot_bgcolor="rgba(0,0,0,0)", margin=dict(l=10, r=10, t=50, b=10), colorway=PALETTE,
                      font=dict(color="#EAEFF8"), title_font_size=15, legend=dict(orientation="h", y=-0.18))
    return fig


def kpi_row(items):
    for col, (label, value, icon, sub) in zip(st.columns(len(items)), items):
        col.markdown(styles.kpi_card(label, value, icon, sub), unsafe_allow_html=True)


def goto(page, **state):
    """on_click callback: jump to another page and pass some session state."""
    st.session_state.update(state)
    st.session_state["nav"] = page


# ---- seat maps -------------------------------------------------------------------------
def render_mini_seatmap(screen_id):
    seats = db.query_df("SELECT row_label, seat_number, seat_type FROM seat WHERE screen_id = ? "
                        "ORDER BY row_label, seat_number", (screen_id,))
    rows = []
    for label, grp in seats.groupby("row_label"):
        types = grp["seat_type"].tolist()
        half = len(types) // 2
        dots = "".join(f'<span class="cs-dot {t}" title="{label}{i + 1} {t}"></span>'
                       + ('<span class="cs-gap"></span>' if i + 1 == half else "") for i, t in enumerate(types))
        rows.append(f'<div class="cs-mini"><b>{label}</b>{dots}</div>')
    st.markdown('<div class="cs-screen" style="height:30px;font-size:.7rem;padding-top:.2rem">SCREEN</div>' + "".join(rows),
                unsafe_allow_html=True)


def _toggle_seat(sel_key, seat_id, max_seats):
    selected = st.session_state[sel_key]
    if seat_id in selected:
        selected.remove(seat_id)
    elif len(selected) < max_seats:
        selected.append(seat_id)
    else:
        st.toast(f"You can select up to {max_seats} seats per booking.", icon="⚠️")


def render_seat_map(show_id, key_prefix, max_seats=10):
    """Interactive seat map. Returns (selected_seats_df, total_price)."""
    sel_key = f"{key_prefix}_sel"
    if st.session_state.get(f"{key_prefix}_show") != show_id:
        st.session_state[f"{key_prefix}_show"] = show_id
        st.session_state[sel_key] = []
    seats = db.get_seat_map(show_id)
    show = db.query_one("SELECT ticket_price FROM show WHERE show_id = ?", (show_id,))
    base = show["ticket_price"]
    booked = set(seats.loc[seats["is_booked"] == 1, "seat_id"])
    st.session_state[sel_key] = [s for s in st.session_state[sel_key] if s not in booked]  # drop seats taken meanwhile
    selected = st.session_state[sel_key]

    st.markdown('<div class="cs-screen">SCREEN</div><div class="cs-legend"><span>🟩 Standard</span><span>🟨 Premium</span>'
                '<span>🟪 VIP</span><span>🟥 Booked</span><span>⬜ Selected</span></div>', unsafe_allow_html=True)
    with st.container(key=f"seatmap_{key_prefix}"):
        for row_label, grp in seats.groupby("row_label"):
            grp = grp.sort_values("seat_number")
            n, half = len(grp), len(grp) // 2
            cols = st.columns([0.6] + [1] * half + [0.45] + [1] * (n - half))
            cols[0].markdown(f'<div class="cs-rowlabel">{row_label}</div>', unsafe_allow_html=True)
            for idx, seat in enumerate(grp.itertuples()):
                col = cols[1 + idx if idx < half else 2 + idx]
                key = f"{key_prefix}_seat_{seat.seat_id}"
                if seat.is_booked:
                    col.button(f"🟥 {seat.seat_label}", key=key, disabled=True)
                elif seat.seat_id in selected:
                    col.button(f"⬜ {seat.seat_label}", key=key, type="primary", on_click=_toggle_seat,
                               args=(sel_key, seat.seat_id, max_seats))
                else:
                    col.button(f"{SEAT_EMOJI[seat.seat_type]} {seat.seat_label}", key=key, on_click=_toggle_seat,
                               args=(sel_key, seat.seat_id, max_seats))

    chosen = seats[seats["seat_id"].isin(selected)].copy()
    chosen["price"] = chosen["seat_type"].map(lambda t: db.seat_price(base, t)).astype(float)
    total = round(float(chosen["price"].sum()), 2)
    prices = sorted(set(chosen["price"])) if len(chosen) else [base]
    price_txt = money(prices[0]) if len(prices) == 1 else f"{money(prices[0])} – {money(prices[-1])}"
    c1, c2, c3, c4 = st.columns([2, 1, 1.3, 1.3])
    c1.metric("Selected Seats", ", ".join(chosen["seat_label"]) if len(chosen) else "—")
    c2.metric("Number of Tickets", len(chosen))
    c3.metric("Price per Seat", price_txt)
    c4.metric("Total Price", money(total))
    st.caption(f"Base price {money(base)} · Standard ×1.00 · Premium ×1.25 · VIP ×1.60. Booked seats cannot be selected.")
    return chosen, total


# ---- ticket ----------------------------------------------------------------------------
def barcode_svg(code):
    """Decorative barcode derived from the ticket code (visual only)."""
    bits = "1011" + "".join(format(ord(ch), "08b") for ch in code) + "1101"
    bars, x, i = [], 0, 0
    while i < len(bits):
        j = i
        while j < len(bits) and bits[j] == bits[i]:
            j += 1
        if bits[i] == "1":
            bars.append(f'<rect x="{x * 2}" y="0" width="{(j - i) * 2}" height="52" fill="#111"/>')
        x += j - i
        i = j
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{x * 2}" height="52" viewBox="0 0 {x * 2} 52">{"".join(bars)}</svg>'


def ticket_html(t):
    e = {k: html.escape(str(val)) for k, val in t.items()}
    void = t["booking_status"] == "Cancelled"
    stamp = ('<div style="position:absolute;top:42%;left:20%;transform:rotate(-14deg);border:4px solid #ef4444;color:#ef4444;'
             'padding:.2rem 1.2rem;font-size:2rem;font-weight:800;letter-spacing:.2em;opacity:.8">VOID</div>') if void else ""
    pay_color = "#16a34a" if t["payment_status"] in ("Paid",) else "#b45309"
    return f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>CineSphere Ticket {e['ticket_code']}</title>
<style>
body{{margin:0;padding:14px;background:transparent;font-family:'Segoe UI',Arial,sans-serif;}}
.ticket{{position:relative;display:flex;max-width:760px;margin:auto;border-radius:18px;overflow:hidden;border:2px solid #F5B301;
  background:#fffdf5;color:#111;box-shadow:0 10px 30px rgba(0,0,0,.35);}}
.main{{flex:1;padding:18px 24px;background:linear-gradient(135deg,#0b1020,#1b2556);color:#fff;}}
.brand{{color:#F5B301;font-weight:800;letter-spacing:.14em;font-size:.85rem;}}
.movie{{font-size:1.7rem;font-weight:800;margin:.35rem 0 .7rem;}}
.grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:.55rem 1rem;}}
.grid small{{display:block;color:#9aa6c4;font-size:.65rem;text-transform:uppercase;letter-spacing:.08em;}}
.grid b{{font-size:.98rem;}}
.stub{{width:210px;padding:16px;background:#fffdf5;border-left:2px dashed #F5B301;text-align:center;display:flex;
  flex-direction:column;justify-content:center;align-items:center;gap:6px;}}
.seat{{font-size:2.2rem;font-weight:800;color:#b8860b;line-height:1}}
.code{{font-family:monospace;font-size:.78rem;letter-spacing:.04em}}
.pay{{font-weight:700;color:{pay_color};font-size:.8rem}}
@media print{{body{{padding:0}}}}
</style></head><body>
<div class="ticket">{stamp}
 <div class="main"><div class="brand">🎬 CINESPHERE · CINEMA TICKET</div>
  <div class="movie">{e['movie']}</div>
  <div class="grid">
    <div><small>Customer</small><b>{e['customer']}</b></div><div><small>Screen</small><b>{e['screen']}</b></div>
    <div><small>Date</small><b>{e['show_date']}</b></div><div><small>Start time</small><b>{e['start_time']}</b></div>
    <div><small>Booking ID</small><b>#{e['booking_id']}</b></div><div><small>Ticket ID</small><b>#{e['ticket_id']}</b></div>
  </div></div>
 <div class="stub"><small>SEAT</small><div class="seat">{e['seat']}</div><div>{e['seat_type']}</div>
  {barcode_svg(t['ticket_code'])}<div class="code">{e['ticket_code']}</div>
  <div class="pay">Payment: {e['payment_status']}</div></div>
</div></body></html>"""
