"""Cinema-themed CSS and small HTML component builders."""
import streamlit as st

CSS = """
<style>
:root{--gold:#F5B301;--navy:#0b1020;--card:#131a30;--card2:#1a2240;--line:rgba(245,179,1,.22);
      --muted:#9aa6c4;--green:#22c55e;--red:#ef4444;}
.stApp{background:radial-gradient(1200px 600px at 8% -10%,#1b2556 0%,#0b1020 55%) fixed;}
#MainMenu, footer{visibility:hidden;}
header[data-testid="stHeader"]{background:transparent;}
.block-container{padding-top:1.6rem;max-width:1400px;}
[data-testid="stSidebar"]{background:linear-gradient(180deg,#0e1530,#090e1e);border-right:1px solid var(--line);}
h1,h2,h3{letter-spacing:.2px;}

/* header */
.cs-header{padding:1.1rem 1.5rem;border:1px solid var(--line);border-radius:18px;margin-bottom:1.1rem;
  background:linear-gradient(90deg,rgba(245,179,1,.16),rgba(19,26,48,.55));}
.cs-header h1{margin:0;font-size:1.75rem;color:#fff;padding:0;}
.cs-header p{margin:.15rem 0 0;color:var(--muted);font-size:.95rem;}
.cs-logo{font-size:1.45rem;font-weight:800;color:var(--gold);letter-spacing:.5px;}
.cs-logo small{display:block;font-size:.68rem;font-weight:500;color:var(--muted);letter-spacing:.3px;}

/* KPI cards */
.cs-kpi{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:.9rem 1.1rem;height:100%;}
.cs-kpi .lbl{color:var(--muted);font-size:.72rem;text-transform:uppercase;letter-spacing:.09em;}
.cs-kpi .val{font-size:1.75rem;font-weight:700;color:var(--gold);line-height:1.25;}
.cs-kpi .sub{color:var(--muted);font-size:.72rem;}
[data-testid="stMetric"]{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:.7rem 1rem;}
[data-testid="stMetricValue"]{color:var(--gold);}
[data-testid="stVerticalBlockBorderWrapper"]{border-radius:16px;}
[data-testid="stTabs"] button[role="tab"]{font-weight:600;}

/* buttons */
.stButton>button,.stDownloadButton>button,.stFormSubmitButton>button{border-radius:10px;border:1px solid var(--line);
  background:var(--card2);color:#EAEFF8;font-weight:600;}
.stButton>button:hover,.stDownloadButton>button:hover,.stFormSubmitButton>button:hover{border-color:var(--gold);color:var(--gold);}
button[kind^="primary"]{background:var(--gold)!important;color:#141414!important;border:0!important;}
button[kind^="primary"]:hover{filter:brightness(1.1);color:#000!important;}
[class*="st-key-danger"] button{background:#7f1d1d!important;border:1px solid var(--red)!important;color:#fff!important;}
[class*="st-key-danger"] button:hover{background:#991b1b!important;}

/* seat map */
.cs-screen{height:44px;margin:.2rem auto 1.3rem;width:78%;border-radius:50% 50% 0 0/100% 100% 0 0;
  background:linear-gradient(180deg,rgba(245,179,1,.55),rgba(245,179,1,0));border-top:3px solid var(--gold);
  text-align:center;color:#fff;letter-spacing:.7em;font-weight:700;padding-top:.55rem;box-shadow:0 -12px 30px rgba(245,179,1,.22);}
.cs-legend{display:flex;gap:1.1rem;flex-wrap:wrap;justify-content:center;color:var(--muted);font-size:.82rem;margin-bottom:.8rem;}
.cs-rowlabel{font-weight:700;color:var(--gold);text-align:center;padding-top:.45rem;}
[class*="st-key-seatmap"] button{padding:.1rem 0;font-size:.76rem;min-height:2.1rem;width:100%;white-space:nowrap;}
[class*="st-key-seatmap"] [data-testid="stHorizontalBlock"]{gap:.3rem;}
.cs-mini{display:flex;gap:3px;margin:3px 0;align-items:center;}
.cs-mini b{width:18px;color:var(--gold);font-size:.75rem;}
.cs-dot{width:14px;height:14px;border-radius:4px;display:inline-block;}
.cs-dot.Standard{background:#22c55e}.cs-dot.Premium{background:#F5B301}.cs-dot.VIP{background:#a855f7}
.cs-gap{width:12px;display:inline-block;}

/* badges */
.cs-badge{display:inline-block;padding:.12rem .65rem;border-radius:999px;font-size:.74rem;font-weight:700;border:1px solid;}
.cs-badge.green{color:#22c55e;border-color:#22c55e;background:rgba(34,197,94,.1)}
.cs-badge.gold{color:#F5B301;border-color:#F5B301;background:rgba(245,179,1,.1)}
.cs-badge.red{color:#ef4444;border-color:#ef4444;background:rgba(239,68,68,.1)}
.cs-badge.grey{color:#9aa6c4;border-color:#4b5575;background:rgba(154,166,196,.08)}
.cs-badge.blue{color:#60a5fa;border-color:#60a5fa;background:rgba(96,165,250,.1)}

/* cards */
.cs-card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:1rem 1.1rem;margin-bottom:.6rem;}
.cs-card h4{margin:0 0 .25rem;color:#fff;} .cs-card .meta{color:var(--muted);font-size:.82rem;}
.cs-item .price{color:var(--gold);font-size:1.3rem;font-weight:700;}
.cs-confirm{background:linear-gradient(180deg,rgba(34,197,94,.12),var(--card));border:1px solid var(--green);
  border-radius:18px;padding:1.4rem 1.6rem;}
.cs-confirm h2{color:var(--green);margin:0 0 .8rem;}
.cs-row{display:flex;justify-content:space-between;gap:1rem;border-bottom:1px dashed rgba(255,255,255,.14);padding:.38rem 0;}
.cs-row span:first-child{color:var(--muted);}
.cs-steps{display:flex;gap:.45rem;flex-wrap:wrap;margin-bottom:.8rem;}
.cs-step{padding:.25rem .8rem;border-radius:999px;border:1px solid #3a4468;color:var(--muted);font-size:.78rem;}
.cs-step.active{background:var(--gold);color:#111;border-color:var(--gold);font-weight:700;}
.cs-step.done{border-color:var(--green);color:var(--green);}
.cs-policy{width:100%;border-collapse:collapse;font-size:.9rem;}
.cs-policy td,.cs-policy th{padding:.4rem .7rem;border-bottom:1px solid rgba(255,255,255,.1);text-align:left;}
.cs-policy th{color:var(--gold);}
</style>
"""


def inject_css():
    st.markdown(CSS, unsafe_allow_html=True)


def kpi_card(label, value, icon="", sub=""):
    return (f'<div class="cs-kpi"><div class="lbl">{icon} {label}</div><div class="val">{value}</div>'
            f'<div class="sub">{sub}</div></div>')


def badge(text, kind="gold"):
    return f'<span class="cs-badge {kind}">{text}</span>'
