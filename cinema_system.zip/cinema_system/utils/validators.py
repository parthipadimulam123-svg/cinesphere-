"""Input validators. Each returns an error message (str) or None when the value is valid."""
import re

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")


def collect(*messages):
    """Keep only real error messages."""
    return [m for m in messages if m]


def required(value, label):
    return None if value is not None and str(value).strip() else f"{label} is required."


def positive_number(value, label):
    try:
        return None if float(value) > 0 else f"{label} must be greater than 0."
    except (TypeError, ValueError):
        return f"{label} must be a valid number."


def positive_int(value, label):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return f"{label} must be a whole number."
    if number != int(number):
        return f"{label} must be a whole number."
    return None if number > 0 else f"{label} must be greater than 0."


def validate_email(email):
    if not email or not str(email).strip():
        return "Email is required."
    return None if EMAIL_RE.match(str(email).strip()) else "Please enter a valid email address (e.g. name@example.com)."


def validate_phone(phone):
    if not phone or not str(phone).strip():
        return "Phone number is required."
    digits = re.sub(r"[\s\-().+]", "", str(phone))
    if not digits.isdigit() or not 7 <= len(digits) <= 15:
        return "Phone number must contain 7-15 digits (spaces, +, - allowed)."
    return None


def validate_name(name):
    if not name or len(str(name).strip()) < 2:
        return "Full name must be at least 2 characters."
    return None
