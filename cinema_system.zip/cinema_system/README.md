# 🎬 CineSphere – Cinema Management & Booking System
*Smart Cinema Operations, Booking & Analytics Platform*

A complete university-grade prototype: Streamlit GUI, SQLite database normalised to 3NF, role-based login,
visual seat map, atomic booking transactions, automatic refund policy and a full analytics suite.

## Features
- **Dashboard** – 6 KPI cards, 6 interactive Plotly charts, upcoming shows with live occupancy
- **Movies** – full CRUD, search by title / genre / language, safe delete with confirmation
- **Screens & Seats** – add / edit screens, automatic seat generation (A1…F10), Standard / Premium / VIP rows, visual layout preview
- **Show Scheduling** – end time = start + duration + cleaning buffer, overlap prevention, filters, status badges
- **Seat Availability** – cinema-style seat map (🟩 🟨 🟪 🟥 ⬜), running totals
- **Customer Booking** – 7-step guided wizard ending in a "BOOKING CONFIRMED ✓" card
- **Tickets** – styled digital ticket with barcode, downloadable as HTML (print from the browser)
- **Bookings / Payments / Concessions (POS) / Cancellations & Refunds**
- **Reports & Analytics** – 6 tabs backed by SQL views
- **Database Explorer** – browse every table/view + schema, plus a **Constraint Lab** that proves the rules live
- **About** – normalisation (1NF–3NF), functional dependencies, anomalies, data dictionary

## Technology
Python 3 · Streamlit · SQLite (`sqlite3`) · Pandas · Plotly · `hashlib` · `datetime`

## Installation & run
```bash
pip install -r requirements.txt
streamlit run app.py
```
The database (`cinesphere.db`) is created automatically on first launch: tables, indexes, triggers, views and
realistic sample data (8 movies, 4 screens, 220 seats, 15 customers, 64 shows, ~470 bookings, payments, concession
sales and cancellations/refunds in every refund tier). To reset the demo data, stop the app and delete `cinesphere.db`.

## Default logins (academic prototype only)
| Role | Username | Password | Access |
|---|---|---|---|
| Admin | `admin` | `admin123` | everything |
| Staff | `staff` | `staff123` | Dashboard, Bookings, Seat Availability, Ticket, Concessions, Payments |

Passwords are stored as salted SHA-256 hashes. To let Staff also use *Customer Booking*, add it to `ROLE_PAGES["Staff"]` in `app.py`.

## Project structure
```
app.py            entry point, login, sidebar navigation, role access
database.py       connection, transactions, business rules, queries (no UI code)
schema.sql        tables, constraints, indexes, triggers, views
seed_data.py      demo data generator (dates relative to today)
views/            one module per page (named views/ because a folder called pages/
                  would trigger Streamlit's automatic multipage navigation)
utils/            validators.py, helpers.py (seat map, ticket, charts), styles.py (CSS)
.streamlit/config.toml   dark/gold theme
```

## Database (3NF)
`customer, movie, screen, seat, show, booking, booking_seat, payment, ticket, concession_item, concession_sale,
concession_sale_item, cancellation, refund` (+ `app_user` for login).
Views: `vw_show_occupancy, vw_movie_performance, vw_screen_utilization, vw_concession_performance,
vw_cancellation_summary, vw_revenue_summary` (+ helper views `vw_ticket_sales, vw_daily_revenue, vw_booking_details`).

## Important constraints & rules
| Rule | Enforcement |
|---|---|
| One seat per screening | Unique index on `booking_seat(show_id, seat_id)` **for active seats**. A cancelled booking marks its seats `Released`, so they can be rebooked while history is kept |
| No screen overlap | Python check + `BEFORE INSERT/UPDATE` triggers: `new_start < existing_end AND new_end > existing_start` |
| Positive quantity / prices | `CHECK` constraints (`quantity > 0`, `ticket_price > 0`, `unit_price > 0`, `amount >= 0`, `refund_amount >= 0`) |
| Stock never negative | `CHECK (stock_quantity >= 0)` + quantity ≤ stock validation |
| Refund ≤ payment | Trigger `trg_refund_not_above_payment` + `min()` in the calculation |
| No cancellation after start | Trigger `trg_cancel_before_show_start` + eligibility check |
| Atomic booking | one transaction: verify seats → booking → booking_seat → payment → tickets; any error ⇒ `ROLLBACK` |
| SQL injection | every query is parameterised |

Cancellation policy: 24h+ → 100% · 6–24h → 75% · 2–6h → 50% · <2h → 0% · after start → prohibited.

## Suggested demo flow
Dashboard → add a movie → schedule a show → schedule an overlapping one (blocked) → seat map →
book seats → open the ticket → sell concessions → mark a pending payment as paid → cancel a booking (refund computed) →
seat becomes free again → Reports → Database Explorer → **Constraint Lab** (double-booking, overlap, negative price, refund cap) → About.
