"""
CineSphere data-access & business-rule layer.

* No Streamlit imports here -> UI and database logic stay separated.
* Every query is parameterised (no string concatenation of user input).
* Multi-step writes (booking, cancellation, concession sale) run inside one transaction.
"""
import hashlib
import os
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta

import pandas as pd

from utils import validators as v

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "cinesphere.db")
SCHEMA_PATH = os.path.join(BASE_DIR, "schema.sql")

DT_FMT = "%Y-%m-%d %H:%M:%S"
PAYMENT_METHODS = ["Cash", "Card", "Digital Wallet"]
SEAT_MULTIPLIER = {"Standard": 1.0, "Premium": 1.25, "VIP": 1.6}
# (minimum hours before show, refund %, label)
CANCEL_POLICY = [(24, 100, "24+ hours before show"), (6, 75, "6 - 24 hours"),
                 (2, 50, "2 - 6 hours"), (0, 0, "Under 2 hours")]


class BusinessError(Exception):
    """A rule violation whose message is safe to show to the user."""


# ----------------------------------------------------------------------------
# Connection helpers
# ----------------------------------------------------------------------------
def get_conn():
    conn = sqlite3.connect(DB_PATH, isolation_level=None, check_same_thread=False)  # autocommit; BEGIN is explicit
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def transaction():
    """BEGIN ... COMMIT, or ROLLBACK if anything raises."""
    conn = get_conn()
    try:
        conn.execute("BEGIN IMMEDIATE")
        yield conn
        conn.execute("COMMIT")
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        raise
    finally:
        conn.close()


def query_df(sql, params=()):
    conn = get_conn()
    try:
        return pd.read_sql_query(sql, conn, params=params)
    finally:
        conn.close()


def query_all(sql, params=()):
    conn = get_conn()
    try:
        return [dict(r) for r in conn.execute(sql, params).fetchall()]
    finally:
        conn.close()


def query_one(sql, params=()):
    rows = query_all(sql, params)
    return rows[0] if rows else None


def execute(sql, params=()):
    conn = get_conn()
    try:
        return conn.execute(sql, params).lastrowid
    finally:
        conn.close()


def friendly_error(exc):
    """Translate sqlite / business exceptions into messages a normal user can understand."""
    if isinstance(exc, BusinessError):
        return str(exc)
    msg = str(exc)
    for known in ("Schedule conflict", "Cancellation is not allowed", "Refund cannot", "Seat does not belong",
                  "Seat allocation"):
        if known in msg:
            return msg
    rules = [
        ("customer.email", "A customer with this email address already exists."),
        ("screen.screen_name", "A screen with this name already exists."),
        ("concession_item.item_name", "A concession item with this name already exists."),
        ("booking_seat.show_id", "One of the selected seats has already been booked for this show."),
        ("payment.transaction_reference", "Duplicate payment reference - please try again."),
        ("seat.screen_id", "That seat already exists on this screen."),
        ("stock_quantity", "Insufficient stock for one of the selected items."),
        ("FOREIGN KEY constraint failed", "This record is linked to other records (shows, bookings, payments...) "
                                          "so it cannot be deleted or changed safely. Consider archiving it instead."),
        ("CHECK constraint failed", "A value is outside the allowed range (e.g. negative price or quantity)."),
        ("NOT NULL constraint failed", "A required field is missing."),
    ]
    for needle, text in rules:
        if needle in msg:
            return text
    return "The database could not complete this action. Please check your input and try again."


def _fail_if(errors):
    if errors:
        raise BusinessError(" ".join(errors))


# ----------------------------------------------------------------------------
# Bootstrap
# ----------------------------------------------------------------------------
def init_db():
    """Create tables/views/triggers and seed demo data if empty. Returns True when data was seeded."""
    conn = get_conn()
    try:
        with open(SCHEMA_PATH, encoding="utf-8") as fh:
            conn.executescript(fh.read())
        empty = conn.execute("SELECT COUNT(*) FROM movie").fetchone()[0] == 0
    finally:
        conn.close()
    if empty:
        from seed_data import seed_database
        seed_database()
        return True
    return False


def refresh_show_statuses():
    """Derive Upcoming / Now Showing / Completed from the clock (Cancelled stays Cancelled)."""
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    execute("""UPDATE show SET status = CASE
                   WHEN show_date || ' ' || end_time   <= ? THEN 'Completed'
                   WHEN show_date || ' ' || start_time <= ? THEN 'Now Showing'
                   ELSE 'Upcoming' END
               WHERE status <> 'Cancelled'""", (now, now))


# ----------------------------------------------------------------------------
# Users / login
# ----------------------------------------------------------------------------
def _hash(password, salt):
    return hashlib.sha256((salt + password).encode("utf-8")).hexdigest()


def create_user(username, password, role, full_name):
    salt = secrets.token_hex(8)
    return execute("INSERT INTO app_user(username, full_name, role, salt, password_hash) VALUES (?,?,?,?,?)",
                   (username, full_name, role, salt, _hash(password, salt)))


def authenticate(username, password):
    user = query_one("SELECT * FROM app_user WHERE username = ?", (username.strip().lower(),))
    if user and secrets.compare_digest(user["password_hash"], _hash(password, user["salt"])):
        return {"username": user["username"], "role": user["role"], "full_name": user["full_name"]}
    return None


# ----------------------------------------------------------------------------
# Customers
# ----------------------------------------------------------------------------
def add_customer(full_name, email, phone):
    _fail_if(v.collect(v.validate_name(full_name), v.validate_email(email), v.validate_phone(phone)))
    return execute("INSERT INTO customer(full_name, email, phone) VALUES (?,?,?)",
                   (full_name.strip(), email.strip().lower(), phone.strip()))


def search_customers(text=""):
    like = f"%{text.strip()}%"
    return query_df("""SELECT customer_id, full_name, email, phone, created_at FROM customer
                       WHERE full_name LIKE ? OR email LIKE ? OR phone LIKE ?
                       ORDER BY full_name LIMIT 100""", (like, like, like))


# ----------------------------------------------------------------------------
# Movies (CRUD)
# ----------------------------------------------------------------------------
def get_movies():
    return query_df("""SELECT movie_id, title, genre, duration_minutes, language, rating, release_date, status
                       FROM movie ORDER BY title""")


def save_movie(data, movie_id=None):
    _fail_if(v.collect(v.required(data.get("title"), "Title"), v.required(data.get("genre"), "Genre"),
                       v.positive_int(data.get("duration_minutes"), "Duration"),
                       v.required(data.get("language"), "Language")))
    vals = (data["title"].strip(), data["genre"].strip(), int(data["duration_minutes"]), data["language"],
            data["rating"], str(data["release_date"]), data["status"])
    if movie_id is None:
        return execute("""INSERT INTO movie(title, genre, duration_minutes, language, rating, release_date, status)
                          VALUES (?,?,?,?,?,?,?)""", vals)
    execute("""UPDATE movie SET title=?, genre=?, duration_minutes=?, language=?, rating=?, release_date=?, status=?
               WHERE movie_id=?""", vals + (movie_id,))
    return movie_id


def delete_movie(movie_id):
    execute("DELETE FROM movie WHERE movie_id = ?", (movie_id,))  # FK RESTRICT protects scheduled movies


# ----------------------------------------------------------------------------
# Screens & seats
# ----------------------------------------------------------------------------
def get_screens():
    return query_df("""SELECT sc.screen_id, sc.screen_name, sc.screen_type, sc.capacity, sc.status,
                              (SELECT COUNT(*) FROM seat s WHERE s.screen_id = sc.screen_id AND s.seat_type='Standard') AS standard_seats,
                              (SELECT COUNT(*) FROM seat s WHERE s.screen_id = sc.screen_id AND s.seat_type='Premium')  AS premium_seats,
                              (SELECT COUNT(*) FROM seat s WHERE s.screen_id = sc.screen_id AND s.seat_type='VIP')      AS vip_seats
                       FROM screen sc ORDER BY sc.screen_name""")


def _validate_layout(rows, per_row, premium_rows, vip_rows):
    errs = v.collect(v.positive_int(rows, "Rows"), v.positive_int(per_row, "Seats per row"))
    _fail_if(errs)
    if rows > 26 or per_row > 30:
        raise BusinessError("A screen can have at most 26 rows (A-Z) and 30 seats per row.")
    if premium_rows + vip_rows > rows:
        raise BusinessError("Premium + VIP rows cannot exceed the total number of rows.")


def _insert_seats(conn, screen_id, rows, per_row, premium_rows, vip_rows):
    data = []
    for i in range(rows):
        seat_type = "VIP" if i >= rows - vip_rows else "Premium" if i >= rows - vip_rows - premium_rows else "Standard"
        data += [(screen_id, chr(65 + i), n, seat_type) for n in range(1, per_row + 1)]
    conn.executemany("INSERT INTO seat(screen_id, row_label, seat_number, seat_type) VALUES (?,?,?,?)", data)


def create_screen(name, screen_type, rows, per_row, premium_rows=0, vip_rows=0):
    _fail_if(v.collect(v.required(name, "Screen name")))
    _validate_layout(rows, per_row, premium_rows, vip_rows)
    with transaction() as conn:
        screen_id = conn.execute("INSERT INTO screen(screen_name, capacity, screen_type, status) VALUES (?,?,?, 'Active')",
                                 (name.strip(), rows * per_row, screen_type)).lastrowid
        _insert_seats(conn, screen_id, rows, per_row, premium_rows, vip_rows)
    return screen_id


def regenerate_seats(screen_id, rows, per_row, premium_rows, vip_rows):
    _validate_layout(rows, per_row, premium_rows, vip_rows)
    with transaction() as conn:
        used = conn.execute("""SELECT COUNT(*) FROM booking_seat bs INNER JOIN seat s ON s.seat_id = bs.seat_id
                               WHERE s.screen_id = ?""", (screen_id,)).fetchone()[0]
        if used:
            raise BusinessError("Seats cannot be regenerated because bookings already exist for this screen.")
        conn.execute("DELETE FROM seat WHERE screen_id = ?", (screen_id,))
        _insert_seats(conn, screen_id, rows, per_row, premium_rows, vip_rows)
        conn.execute("UPDATE screen SET capacity = ? WHERE screen_id = ?", (rows * per_row, screen_id))


def set_row_type(screen_id, row_label, seat_type):
    execute("UPDATE seat SET seat_type = ? WHERE screen_id = ? AND row_label = ?", (seat_type, screen_id, row_label))


def update_screen(screen_id, name, screen_type, status):
    _fail_if(v.collect(v.required(name, "Screen name")))
    execute("UPDATE screen SET screen_name=?, screen_type=?, status=? WHERE screen_id=?",
            (name.strip(), screen_type, status, screen_id))


def delete_screen(screen_id):
    execute("DELETE FROM screen WHERE screen_id = ?", (screen_id,))


def seat_price(base_price, seat_type):
    return round(float(base_price) * SEAT_MULTIPLIER[seat_type], 2)


def get_seat_map(show_id):
    """All seats of the show's screen with a booked flag (only ACTIVE allocations block a seat)."""
    return query_df("""SELECT s.seat_id, s.row_label, s.seat_number, s.seat_type,
                              s.row_label || s.seat_number AS seat_label,
                              CASE WHEN bs.booking_seat_id IS NULL THEN 0 ELSE 1 END AS is_booked
                       FROM show sh
                       INNER JOIN seat s ON s.screen_id = sh.screen_id
                       LEFT JOIN booking_seat bs ON bs.seat_id = s.seat_id AND bs.show_id = sh.show_id
                                                 AND bs.seat_status = 'Active'
                       WHERE sh.show_id = ?
                       ORDER BY s.row_label, s.seat_number""", (show_id,))


# ----------------------------------------------------------------------------
# Show scheduling
# ----------------------------------------------------------------------------
def calc_end_time(start_time, duration_minutes, buffer_minutes=15):
    start = datetime.strptime(start_time, "%H:%M")
    end = start + timedelta(minutes=int(duration_minutes) + int(buffer_minutes))
    if end.date() != start.date():
        raise BusinessError("This show would run past midnight. Please choose an earlier start time.")
    return end.strftime("%H:%M")


def find_overlap(screen_id, show_date, start, end, exclude_show_id=-1):
    """Rule B: new_start < existing_end AND new_end > existing_start (same screen & date)."""
    return query_one("""SELECT sh.show_id, m.title, sh.start_time, sh.end_time, sc.screen_name
                        FROM show sh
                        INNER JOIN movie m  ON m.movie_id = sh.movie_id
                        INNER JOIN screen sc ON sc.screen_id = sh.screen_id
                        WHERE sh.screen_id = ? AND sh.show_date = ? AND sh.status <> 'Cancelled'
                          AND ? < sh.end_time AND ? > sh.start_time AND sh.show_id <> ?""",
                     (screen_id, show_date, start, end, exclude_show_id))


def add_show(movie_id, screen_id, show_date, start_time, ticket_price, buffer_minutes=15, allow_past=False):
    _fail_if(v.collect(v.positive_number(ticket_price, "Ticket price")))
    movie = query_one("SELECT * FROM movie WHERE movie_id = ?", (movie_id,))
    screen = query_one("SELECT * FROM screen WHERE screen_id = ?", (screen_id,))
    if not movie or not screen:
        raise BusinessError("Please select a valid movie and screen.")
    if movie["status"] == "Archived":
        raise BusinessError("Archived movies cannot be scheduled.")
    if screen["status"] != "Active":
        raise BusinessError(f"{screen['screen_name']} is not active (status: {screen['status']}).")
    show_date, start_time = str(show_date), str(start_time)[:5]
    if not allow_past and datetime.strptime(f"{show_date} {start_time}", "%Y-%m-%d %H:%M") <= datetime.now():
        raise BusinessError("A show cannot be scheduled in the past.")
    end_time = calc_end_time(start_time, movie["duration_minutes"], buffer_minutes)
    clash = find_overlap(screen_id, show_date, start_time, end_time)
    if clash:
        raise BusinessError(f"Schedule conflict: {clash['screen_name']} already has a movie during this time "
                            f"('{clash['title']}' {clash['start_time']}-{clash['end_time']}).")
    return execute("""INSERT INTO show(movie_id, screen_id, show_date, start_time, end_time, ticket_price, status)
                      VALUES (?,?,?,?,?,?, 'Upcoming')""",
                   (movie_id, screen_id, show_date, start_time, end_time, round(float(ticket_price), 2)))


def _show_has_bookings(show_id):
    return query_one("SELECT COUNT(*) AS n FROM booking WHERE show_id = ?", (show_id,))["n"] > 0


def update_show_price(show_id, price):
    _fail_if(v.collect(v.positive_number(price, "Ticket price")))
    if _show_has_bookings(show_id):
        raise BusinessError("The price cannot be changed because bookings already exist for this show.")
    execute("UPDATE show SET ticket_price = ? WHERE show_id = ?", (round(float(price), 2), show_id))


def cancel_show(show_id):
    active = query_one("""SELECT COUNT(*) AS n FROM booking WHERE show_id = ? AND booking_status <> 'Cancelled'""", (show_id,))["n"]
    if active:
        raise BusinessError(f"This show has {active} active booking(s). Cancel/refund them first.")
    execute("UPDATE show SET status = 'Cancelled' WHERE show_id = ?", (show_id,))


def delete_show(show_id):
    if _show_has_bookings(show_id):
        raise BusinessError("Shows with booking history cannot be deleted (financial records are protected). Cancel it instead.")
    execute("DELETE FROM show WHERE show_id = ?", (show_id,))


def get_shows(open_only=False):
    sql = "SELECT * FROM vw_show_occupancy"
    if open_only:
        sql += " WHERE status IN ('Upcoming','Now Showing')"
    return query_df(sql + " ORDER BY show_date, start_time, screen_name")


# ----------------------------------------------------------------------------
# Booking (atomic)
# ----------------------------------------------------------------------------
def _reference(prefix):
    return f"{prefix}-{datetime.now():%Y%m%d}-{secrets.token_hex(3).upper()}"


def _issue_tickets(conn, booking_id, show_id, issued_at):
    rows = conn.execute("""SELECT booking_seat_id FROM booking_seat
                           WHERE booking_id = ? AND seat_status = 'Active'
                             AND booking_seat_id NOT IN (SELECT booking_seat_id FROM ticket)""", (booking_id,)).fetchall()
    for r in rows:
        conn.execute("INSERT INTO ticket(booking_id, booking_seat_id, ticket_code, issued_at) VALUES (?,?,?,?)",
                     (booking_id, r["booking_seat_id"], f"CS{show_id:04d}-{secrets.token_hex(4).upper()}", issued_at))


def create_booking(customer_id, show_id, seat_ids, payment_method, payment_status="Paid",
                   booking_dt=None, allow_past=False):
    """
    BEGIN -> verify seats -> booking -> booking_seat rows -> payment -> tickets -> COMMIT.
    Any failure rolls the whole transaction back.
    """
    seat_ids = list(dict.fromkeys(int(s) for s in seat_ids))
    if not seat_ids:
        raise BusinessError("Please select at least one seat.")
    if payment_method not in PAYMENT_METHODS:
        raise BusinessError("Please choose a valid payment method.")
    when = (booking_dt or datetime.now()).strftime(DT_FMT)
    try:
        with transaction() as conn:
            show = conn.execute("SELECT * FROM show WHERE show_id = ?", (show_id,)).fetchone()
            if show is None:
                raise BusinessError("The selected show no longer exists.")
            if show["status"] == "Cancelled":
                raise BusinessError("This show has been cancelled.")
            start = datetime.strptime(f"{show['show_date']} {show['start_time']}", "%Y-%m-%d %H:%M")
            if not allow_past and start <= datetime.now():
                raise BusinessError("Booking is closed because this show has already started.")
            if conn.execute("SELECT 1 FROM customer WHERE customer_id = ?", (customer_id,)).fetchone() is None:
                raise BusinessError("Please select a valid customer.")
            marks = ",".join("?" * len(seat_ids))
            # 1. verify seat availability
            seats = conn.execute(f"""SELECT seat_id, screen_id, row_label, seat_number, seat_type FROM seat
                                     WHERE seat_id IN ({marks}) ORDER BY row_label, seat_number""", seat_ids).fetchall()
            if len(seats) != len(seat_ids) or any(s["screen_id"] != show["screen_id"] for s in seats):
                raise BusinessError("Invalid seat selection for this show.")
            taken = [r[0] for r in conn.execute(
                f"""SELECT s.row_label || s.seat_number FROM booking_seat bs INNER JOIN seat s ON s.seat_id = bs.seat_id
                    WHERE bs.show_id = ? AND bs.seat_status = 'Active' AND bs.seat_id IN ({marks})
                    ORDER BY s.row_label, s.seat_number""", [show_id, *seat_ids]).fetchall()]
            if taken:
                raise BusinessError(f"Seat {taken[0]} has already been booked." if len(taken) == 1
                                    else f"Seats {', '.join(taken)} have already been booked.")
            priced = [(s, seat_price(show["ticket_price"], s["seat_type"])) for s in seats]
            total = round(sum(p for _, p in priced), 2)
            booking_status = {"Paid": "Confirmed", "Pending": "Pending", "Failed": "Cancelled"}[payment_status]
            seat_status = "Released" if payment_status == "Failed" else "Active"
            # 2. booking
            booking_id = conn.execute("""INSERT INTO booking(customer_id, show_id, booking_datetime, booking_status, total_amount)
                                         VALUES (?,?,?,?,?)""", (customer_id, show_id, when, booking_status, total)).lastrowid
            # 3. booking_seat
            for seat, price in priced:
                conn.execute("""INSERT INTO booking_seat(booking_id, show_id, seat_id, price, seat_status)
                                VALUES (?,?,?,?,?)""", (booking_id, show_id, seat["seat_id"], price, seat_status))
            # 4. payment (amount always equals booking total)
            reference = _reference("TXN")
            payment_id = conn.execute("""INSERT INTO payment(booking_id, payment_method, amount, payment_datetime,
                                         payment_status, transaction_reference) VALUES (?,?,?,?,?,?)""",
                                      (booking_id, payment_method, total, when, payment_status, reference)).lastrowid
            # 5. tickets
            if payment_status == "Paid":
                _issue_tickets(conn, booking_id, show_id, when)
        return {"booking_id": booking_id, "payment_id": payment_id, "transaction_reference": reference, "total": total}
    except sqlite3.IntegrityError as exc:  # e.g. race condition on the unique seat index
        raise BusinessError(friendly_error(exc)) from exc


def complete_pending_payment(payment_id):
    try:
        with transaction() as conn:
            pay = conn.execute("SELECT * FROM payment WHERE payment_id = ?", (payment_id,)).fetchone()
            if pay is None or pay["payment_status"] != "Pending":
                raise BusinessError("Only pending payments can be completed.")
            booking = conn.execute("SELECT * FROM booking WHERE booking_id = ?", (pay["booking_id"],)).fetchone()
            conn.execute("UPDATE payment SET payment_status = 'Paid' WHERE payment_id = ?", (payment_id,))
            conn.execute("UPDATE booking SET booking_status = 'Confirmed' WHERE booking_id = ?", (booking["booking_id"],))
            _issue_tickets(conn, booking["booking_id"], booking["show_id"], datetime.now().strftime(DT_FMT))
    except sqlite3.DatabaseError as exc:
        raise BusinessError(friendly_error(exc)) from exc


def get_booking_details(booking_id):
    b = query_one("SELECT * FROM vw_booking_details WHERE booking_id = ?", (booking_id,))
    if not b:
        return None
    b["payment"] = query_one("SELECT * FROM payment WHERE booking_id = ? ORDER BY payment_id DESC LIMIT 1", (booking_id,))
    b["seat_rows"] = query_df("""SELECT s.row_label || s.seat_number AS Seat, s.seat_type AS Type,
                                        bs.price AS Price, bs.seat_status AS Status
                                 FROM booking_seat bs INNER JOIN seat s ON s.seat_id = bs.seat_id
                                 WHERE bs.booking_id = ? ORDER BY s.row_label, s.seat_number""", (booking_id,))
    return b


def get_tickets(booking_id):
    return query_all("""SELECT t.ticket_id, t.ticket_code, t.issued_at, t.booking_id,
                               s.row_label || s.seat_number AS seat, s.seat_type, bs.price,
                               c.full_name AS customer, m.title AS movie, sc.screen_name AS screen,
                               sh.show_date, sh.start_time, b.booking_status,
                               COALESCE((SELECT p.payment_status FROM payment p WHERE p.booking_id = b.booking_id
                                         ORDER BY p.payment_id DESC LIMIT 1), 'None') AS payment_status
                        FROM ticket t
                        INNER JOIN booking_seat bs ON bs.booking_seat_id = t.booking_seat_id
                        INNER JOIN seat s    ON s.seat_id = bs.seat_id
                        INNER JOIN booking b ON b.booking_id = t.booking_id
                        INNER JOIN customer c ON c.customer_id = b.customer_id
                        INNER JOIN show sh   ON sh.show_id = b.show_id
                        INNER JOIN movie m   ON m.movie_id = sh.movie_id
                        INNER JOIN screen sc ON sc.screen_id = sh.screen_id
                        WHERE t.booking_id = ? ORDER BY s.row_label, s.seat_number""", (booking_id,))


# ----------------------------------------------------------------------------
# Cancellation & refund
# ----------------------------------------------------------------------------
def cancellation_quote(booking_id, now=None):
    """Eligibility + refund calculation for a booking at time `now`."""
    now = now or datetime.now()
    b = query_one("""SELECT b.booking_id, b.booking_status, b.total_amount, sh.show_date, sh.start_time
                     FROM booking b INNER JOIN show sh ON sh.show_id = b.show_id WHERE b.booking_id = ?""", (booking_id,))
    if not b:
        raise BusinessError("Booking not found.")
    pay = query_one("SELECT * FROM payment WHERE booking_id = ? ORDER BY payment_id DESC LIMIT 1", (booking_id,))
    start = datetime.strptime(f"{b['show_date']} {b['start_time']}", "%Y-%m-%d %H:%M")
    hours_left = (start - now).total_seconds() / 3600
    quote = {"booking_id": booking_id, "hours_left": hours_left, "eligible": False, "refund_pct": 0,
             "refund_amount": 0.0, "paid_amount": 0.0, "payment_id": pay["payment_id"] if pay else None,
             "payment_status": pay["payment_status"] if pay else None, "show_start": start}
    if b["booking_status"] == "Cancelled":
        quote["message"] = "This booking is already cancelled."
    elif hours_left <= 0:
        quote["message"] = "Cancellation is not allowed because the show has already started."
    else:
        pct = next(p for h, p, _ in CANCEL_POLICY if hours_left >= h)
        paid = float(pay["amount"]) if pay and pay["payment_status"] == "Paid" else 0.0
        refund = min(round(paid * pct / 100, 2), paid)  # never refund more than was paid
        quote.update(eligible=True, refund_pct=pct if paid else 0, refund_amount=refund, paid_amount=paid,
                     message="Eligible for cancellation.")
    return quote


def cancel_booking(booking_id, reason, now=None):
    """Update booking, release seats, insert cancellation (+ refund) in one transaction."""
    if not reason or len(reason.strip()) < 3:
        raise BusinessError("Please provide a cancellation reason.")
    quote = cancellation_quote(booking_id, now)
    if not quote["eligible"]:
        raise BusinessError(quote["message"])
    when = (now or datetime.now()).strftime(DT_FMT)
    try:
        with transaction() as conn:
            conn.execute("UPDATE booking SET booking_status = 'Cancelled' WHERE booking_id = ?", (booking_id,))
            conn.execute("UPDATE booking_seat SET seat_status = 'Released' WHERE booking_id = ?", (booking_id,))
            cancel_id = conn.execute("""INSERT INTO cancellation(booking_id, cancellation_datetime, reason, refund_percentage,
                                        refund_amount, cancellation_status) VALUES (?,?,?,?,?, 'Processed')""",
                                     (booking_id, when, reason.strip(), quote["refund_pct"], quote["refund_amount"])).lastrowid
            if quote["refund_amount"] > 0:
                conn.execute("""INSERT INTO refund(cancellation_id, payment_id, refund_amount, refund_datetime, refund_status)
                                VALUES (?,?,?,?, 'Processed')""", (cancel_id, quote["payment_id"], quote["refund_amount"], when))
                conn.execute("UPDATE payment SET payment_status = 'Refunded' WHERE payment_id = ?", (quote["payment_id"],))
            elif quote["payment_status"] == "Pending":
                conn.execute("UPDATE payment SET payment_status = 'Failed' WHERE payment_id = ?", (quote["payment_id"],))
    except sqlite3.DatabaseError as exc:
        raise BusinessError(friendly_error(exc)) from exc
    return quote


# ----------------------------------------------------------------------------
# Concessions
# ----------------------------------------------------------------------------
def get_items(active_only=True):
    sql = "SELECT item_id, item_name, category, unit_price, stock_quantity, status FROM concession_item"
    return query_df(sql + (" WHERE status = 'Active'" if active_only else "") + " ORDER BY category, item_name")


def complete_concession_sale(cart, customer_id=None, booking_id=None, sale_dt=None):
    """cart = {item_id: quantity}. Validates quantity > 0 and <= stock, then reduces stock atomically."""
    if not cart:
        raise BusinessError("The cart is empty.")
    when = (sale_dt or datetime.now()).strftime(DT_FMT)
    try:
        with transaction() as conn:
            lines = []
            for item_id, qty in cart.items():
                qty = int(qty)
                if qty <= 0:
                    raise BusinessError("Quantity must be greater than zero.")
                item = conn.execute("SELECT * FROM concession_item WHERE item_id = ?", (item_id,)).fetchone()
                if item is None or item["status"] != "Active":
                    raise BusinessError("One of the items is no longer available.")
                if qty > item["stock_quantity"]:
                    raise BusinessError(f"Insufficient stock for {item['item_name']} (only {item['stock_quantity']} left).")
                lines.append((item, qty))
            total = round(sum(i["unit_price"] * q for i, q in lines), 2)
            sale_id = conn.execute("""INSERT INTO concession_sale(customer_id, booking_id, sale_datetime, total_amount)
                                      VALUES (?,?,?,?)""", (customer_id, booking_id, when, total)).lastrowid
            for item, qty in lines:
                conn.execute("""INSERT INTO concession_sale_item(concession_sale_id, item_id, quantity, unit_price)
                                VALUES (?,?,?,?)""", (sale_id, item["item_id"], qty, item["unit_price"]))
                conn.execute("UPDATE concession_item SET stock_quantity = stock_quantity - ? WHERE item_id = ?",
                             (qty, item["item_id"]))
        return sale_id, total
    except sqlite3.DatabaseError as exc:
        raise BusinessError(friendly_error(exc)) from exc


# ----------------------------------------------------------------------------
# Analytics helpers
# ----------------------------------------------------------------------------
def get_dashboard_kpis():
    today = datetime.now().strftime("%Y-%m-%d")
    return query_one("""
        SELECT
          (SELECT COUNT(*) FROM show WHERE show_date = :d AND status <> 'Cancelled')                         AS todays_shows,
          (SELECT COUNT(*) FROM booking_seat WHERE seat_status = 'Active')                                   AS tickets_sold,
          COALESCE((SELECT ticket_revenue + concession_revenue FROM vw_daily_revenue WHERE revenue_date = :d), 0) AS todays_revenue,
          (SELECT COALESCE(SUM(available_seats), 0) FROM vw_show_occupancy
            WHERE show_date = :d AND status IN ('Upcoming','Now Showing'))                                   AS available_seats,
          (SELECT COUNT(*) FROM booking)                                                                     AS total_bookings,
          COALESCE((SELECT ROUND(100.0 * (SELECT COUNT(*) FROM cancellation)
                                 / NULLIF((SELECT COUNT(*) FROM booking), 0), 1)), 0)                        AS cancellation_rate
    """, {"d": today})


def get_view(name):
    if name not in {"vw_show_occupancy", "vw_movie_performance", "vw_screen_utilization", "vw_concession_performance",
                    "vw_cancellation_summary", "vw_revenue_summary", "vw_daily_revenue", "vw_booking_details"}:
        raise ValueError("Unknown view")
    return query_df(f"SELECT * FROM {name}")


def get_payments():
    return query_df("""SELECT p.payment_id, p.transaction_reference, p.booking_id, c.full_name AS customer,
                              p.amount, p.payment_method, p.payment_datetime, p.payment_status
                       FROM payment p
                       INNER JOIN booking b  ON b.booking_id = p.booking_id
                       INNER JOIN customer c ON c.customer_id = b.customer_id
                       ORDER BY p.payment_datetime DESC""")


def get_cancellations():
    return query_df("""SELECT c.cancellation_id, c.booking_id, cu.full_name AS customer, m.title AS movie,
                              c.cancellation_datetime, c.reason, c.refund_percentage, c.refund_amount,
                              COALESCE(r.refund_status, 'No refund') AS refund_status
                       FROM cancellation c
                       INNER JOIN booking b   ON b.booking_id = c.booking_id
                       INNER JOIN customer cu ON cu.customer_id = b.customer_id
                       INNER JOIN show sh     ON sh.show_id = b.show_id
                       INNER JOIN movie m     ON m.movie_id = sh.movie_id
                       LEFT JOIN refund r     ON r.cancellation_id = c.cancellation_id
                       ORDER BY c.cancellation_datetime DESC""")


# ----------------------------------------------------------------------------
# Database explorer
# ----------------------------------------------------------------------------
def list_tables():
    rows = query_all("""SELECT name, type FROM sqlite_master WHERE type IN ('table','view')
                        AND name NOT LIKE 'sqlite_%' ORDER BY type DESC, name""")
    return [r["name"] for r in rows]


def table_data(name):
    if name not in list_tables():
        raise ValueError("Unknown table")
    return query_df(f'SELECT * FROM "{name}"')


def table_schema(name):
    if name not in list_tables():
        raise ValueError("Unknown table")
    return query_df(f'PRAGMA table_info("{name}")')


def run_constraint_demo(kind):
    """Try a rule-breaking write inside a transaction that is ALWAYS rolled back. Returns (friendly, raw)."""
    conn = get_conn()
    try:
        conn.execute("BEGIN")
        if kind == "duplicate_seat":
            r = conn.execute("SELECT * FROM booking_seat WHERE seat_status='Active' LIMIT 1").fetchone()
            conn.execute("INSERT INTO booking_seat(booking_id, show_id, seat_id, price) VALUES (?,?,?,?)",
                         (r["booking_id"], r["show_id"], r["seat_id"], r["price"]))
        elif kind == "overlap":
            r = conn.execute("SELECT * FROM show WHERE status <> 'Cancelled' LIMIT 1").fetchone()
            conn.execute("""INSERT INTO show(movie_id, screen_id, show_date, start_time, end_time, ticket_price, status)
                            VALUES (?,?,?,?,?,?, 'Upcoming')""",
                         (r["movie_id"], r["screen_id"], r["show_date"], r["start_time"], r["end_time"], 10))
        elif kind == "negative_price":
            conn.execute("INSERT INTO concession_item(item_name, category, unit_price, stock_quantity) VALUES ('Test', 'Test', -5, 10)")
        elif kind == "refund_cap":
            r = conn.execute("""SELECT c.cancellation_id, p.payment_id, p.amount FROM cancellation c
                                INNER JOIN payment p ON p.booking_id = c.booking_id LIMIT 1""").fetchone()
            conn.execute("INSERT INTO refund(cancellation_id, payment_id, refund_amount, refund_datetime) VALUES (?,?,?,?)",
                         (r["cancellation_id"], r["payment_id"], r["amount"] + 100, datetime.now().strftime(DT_FMT)))
        return "No constraint fired (unexpected).", ""
    except sqlite3.Error as exc:
        return friendly_error(exc), str(exc)
    finally:
        try:
            conn.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        conn.close()
